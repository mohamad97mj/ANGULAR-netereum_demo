'use strict';

// Declare app level module which depends on views, and core components
var myApp = angular.module('myApp', [
    // 'ngRoute',
    'ui.router',
    'myApp.view1',
    'myApp.view2',
    // 'myApp.version'
]);
myApp.config(function ($urlRouterProvider, $stateProvider) {


    $urlRouterProvider.when('/home', '/about, /getstarted');

    $stateProvider
    // nested views


        .state('home', {
            url: '/home',
            templateUrl: 'view1/view1.html'

        })

        .state('about', {
            url: '/about',
            templateUrl: 'view2/view2.html'

        })

        .state('getstarted', {
            url: '/getstarted',
            templateUrl: 'view3/getstarted.html',
            controller: function ($scope) {
                // $scope.msg = " this is page number 1";
                // $scope.firstName = "John";
            }

        })

        .state('getstarted1', {
            url: '/getstarted1',
            templateUrl: 'view3/subviews/1.html',
            controller: function () {

                // $scope.$on('$locationChangeStart', function(event) {
                //     var answer = confirm("Are you sure you want to leave this page?")
                //     if (!answer) {
                //         event.preventDefault();
                //     }
                // });
            }

        })
        .state('getstarted2', {
            url: '/getstarted2',
            templateUrl: 'view3/subviews/2.html',
            controller: function ($scope, Exchange1, Currencies1, GetRates1) {

                $scope.currencies = Currencies1;
                $scope.exchange = Exchange1;


                $scope.cal1 = function () {

                    var c1 = $scope.exchange.currency1;
                    var c2 = $scope.exchange.currency2;
                    var r = GetRates1.getRates(c1, c2);
                    $scope.exchange.amount2 = ($scope.exchange.amount1 * (r[0] / r[1])).toFixed(0);

                };
            }
        })

        .state('getstarted3', {
            url: '/getstarted3',
            templateUrl: 'view3/subviews/3.html',
            controller: function ($scope, Exchange1, Currencies1) {

                $scope.currencies2 = Currencies1;
                var exchange = Exchange1;
                $scope.amount1 = exchange.amount1;
                $scope.amount2 = exchange.amount2;
                $scope.currency1 = exchange.currency1;
                $scope.currency2 = exchange.currency2;

            }
        })

        .state('getstarted4', {
            url: '/getstarted4',
            templateUrl: 'view3/subviews/4.html',

            controller: function ($scope, Exchange1, Currencies1) {
                $scope.currencies = Currencies1;
                var exchange = Exchange1;
                $scope.amount1 = exchange.amount1;
                $scope.amount2 = exchange.amount2;
                $scope.currency1 = exchange.currency1;
                $scope.currency2 = exchange.currency2;
            }

        })
        .state('getstarted5', {
            url: '/getstarted5',
            templateUrl: 'view3/subviews/5.html',
            controller: function ($scope, Exchange1, Currencies1, GetRates1) {
                $scope.currencies = Currencies1;
                $scope.exchange = Exchange1;
                $scope.sum = "0";

                $scope.doExchange = function () {
                    document.getElementById("sp1").style.visibility = "visible";
                    document.getElementById("sp2").style.visibility = "visible";
                    document.getElementById("sp3").style.visibility = "visible";
                    document.getElementById("sp4").style.visibility = "visible";
                    document.getElementById("sumRow").style.backgroundColor = "#5cb85c";
                    document.getElementById("status").innerHTML = "Done successfully!";
                    // document.getElementById("sumRow").style.backgroundColor = "#d9534f";
                };

                $scope.cal2 = function () {
                    var c1 = $scope.exchange.currency1;
                    var c2 = $scope.exchange.currency2;
                    var r = GetRates1.getRates(c1, c2);
                    $scope.exchange.amount2 = ($scope.exchange.amount1 * (r[0] / r[1])).toFixed(0);
                    document.getElementById("sp1").style.visibility = "hidden";
                    document.getElementById("sp2").style.visibility = "hidden";
                    document.getElementById("sp3").style.visibility = "hidden";
                    document.getElementById("sp4").style.visibility = "hidden";
                    document.getElementById("status").innerHTML = "";
                    document.getElementById("sumRow").style.backgroundColor = "#FFFFFF";

                };
            }
        })

        .state('getstarted6', {
            url: '/getstarted6',
            templateUrl: 'view3/subviews/6.html',
            controller: function ($scope, Exchange1, Exchange2, Currencies1, GetRates1) {
                $scope.currencies = Currencies1;
                $scope.exchange1 = Exchange1;
                $scope.exchange2 = Exchange2;

                $scope.exchange2.amount1 = $scope.exchange1.amount2;
                $scope.exchange2.amount2 = $scope.exchange1.amount1;
                $scope.exchange2.currency1 = $scope.exchange1.currency2;
                $scope.exchange2.currency2 = $scope.exchange1.currency1;


                $scope.sum1 = parseInt($scope.exchange2.amount2) - parseInt($scope.exchange1.amount1);
                $scope.sum2 = parseInt($scope.exchange1.amount2) - parseInt($scope.exchange2.amount1);

                // $scope.sum = "0";
                $scope.doExchange2 = function () {

                    document.getElementById("sp3").style.visibility = "visible";
                    document.getElementById("sp4").style.visibility = "visible";

                    $scope.sum1 = parseInt($scope.exchange2.amount2) - parseInt($scope.exchange1.amount1);
                    $scope.sum2 = parseInt($scope.exchange1.amount2) - parseInt($scope.exchange2.amount1);

                    if ($scope.sum1 === 0) {
                        document.getElementById("sp11").style.display = "block";
                        document.getElementById("sp21").style.display = "block";
                        document.getElementById("sumRow").style.backgroundColor = "#5cb85c";
                        document.getElementById("status").innerHTML = "Successfully Done!";

                    } else {
                        document.getElementById("sp1").style.display = "block";
                        document.getElementById("sp2").style.display = "block";
                        document.getElementById("sumRow").style.backgroundColor = "#d9534f";
                        document.getElementById("status").innerHTML = "Failed!, The amounts are not balanced!, For more information  Go to next page!";

                    }

                };

                $scope.cal3 = function () {

                    document.getElementById("sp3").style.visibility = "hidden";
                    document.getElementById("sp4").style.visibility = "hidden";
                    document.getElementById("sp1").style.display = "none";
                    document.getElementById("sp2").style.display = "none";
                    document.getElementById("sp11").style.display = "none";
                    document.getElementById("sp21").style.display = "none";
                    document.getElementById("sp11").style.display = "none";
                    document.getElementById("sp21").style.display = "none";
                    document.getElementById("sumRow").style.backgroundColor = "#FFFFFF";
                    document.getElementById("status").innerHTML = "";

                    var c1 = $scope.exchange1.currency1;
                    var c2 = $scope.exchange1.currency2;
                    var r = GetRates1.getRates(c1, c2);
                    $scope.exchange1.amount2 = ($scope.exchange1.amount1 * (r[0] / r[1])).toFixed(0);

                };
            }
        })

        .state('getstarted7', {
            url: '/getstarted7',
            templateUrl: 'view3/subviews/7.html'

        })
        .state('getstarted8', {
            url: '/getstarted8',
            templateUrl: 'view3/subviews/8.html'

        })
        .state('getstarted9', {
            url: '/getstarted9',
            templateUrl: 'view3/subviews/9.html',
            controller: function ($scope, Exchange1, Exchange2, Currencies1, GetRates1) {

                // $scope.amount100 = 200;
                $scope.amount100 = 200;

                $scope.currencies = Currencies1;
                var exchange1 = Exchange1;
                var exchange2 = Exchange2;
                $scope.amount11 = exchange2.amount1;
                $scope.amount12 = exchange2.amount2;
                $scope.currency1 = exchange1.currency1;
                $scope.currency2 = exchange1.currency2;
                $scope.amount21 = exchange1.amount2;
                $scope.amount22 = exchange1.amount1;

                $scope.cal4 = function () {
                    var c1 = $scope.currency1;
                    var c2 = $scope.currency2;
                    var r = GetRates1.getRates(c1, c2);
                    $scope.amount12 = ($scope.amount11 * (r[0] / r[1])).toFixed(0);
                    document.getElementById("sp1").style.visibility = "hidden";
                    document.getElementById("sp2").style.visibility = "hidden";
                    document.getElementById("sp3").style.visibility = "hidden";
                    document.getElementById("sp4").style.visibility = "hidden";
                    document.getElementById("sp5").style.visibility = "hidden";
                    document.getElementById("sp6").style.visibility = "hidden";
                    document.getElementById("sp7").style.visibility = "hidden";
                    document.getElementById("sp8").style.visibility = "hidden";
                    document.getElementById("sumRow").style.backgroundColor = "#ffffff";
                    document.getElementById("status").innerHTML = "";
                    exchange2.amount1 = $scope.amount11;
                    exchange2.amount2 = $scope.amount12;


                };

                $scope.doExchange3 = function () {
                    document.getElementById("sp3").style.visibility = "visible";
                    document.getElementById("sp6").style.visibility = "visible";
                    document.getElementById("sp1").style.visibility = "visible";
                    document.getElementById("sp2").style.visibility = "visible";
                    document.getElementById("sp4").style.visibility = "visible";
                    document.getElementById("sp5").style.visibility = "visible";
                    document.getElementById("sp7").style.visibility = "visible";
                    document.getElementById("sp8").style.visibility = "visible";

                    document.getElementById("sumRow").style.backgroundColor = "#5cb85c";
                    document.getElementById("status").innerHTML = "Done successfully!";
                };
            }

        })
        .state('getstarted10', {
            url: '/getstarted10',
            templateUrl: 'view3/subviews/10.html',
            controller: function ($scope, Exchange1, Exchange2, Currencies1, GetRates1) {
            }
        })

        .state('getstarted11', {
            url: '/getstarted11',
            templateUrl: 'view3/subviews/11.html',
            controller: function ($scope, Exchange1, Exchange2, Currencies1, GetRates1) {

                $scope.currencies = Currencies1;
                var exchange1 = Exchange1;
                var exchange2 = Exchange2;
                $scope.amount11 = exchange2.amount1;
                $scope.amount12 = exchange2.amount2;
                $scope.currency1 = exchange1.currency1;
                $scope.currency2 = exchange1.currency2;
                $scope.amount21 = exchange1.amount2;
                $scope.amount22 = exchange1.amount1;


                $scope.credit1 = 3 * Math.abs($scope.amount11 - $scope.amount22) + parseInt($scope.amount11);

                var c1 = $scope.currency1;
                var c2 = $scope.currency2;
                var r = GetRates1.getRates(c1, c2);

                $scope.credit2 = ($scope.credit1 * (r[0] / r[1])).toFixed(0);

                $scope.cal6 = function () {
                    $scope.amount12 = ($scope.amount11 * (r[0] / r[1])).toFixed(0);
                    document.getElementById("sp1").style.visibility = "hidden";
                    document.getElementById("sp2").style.visibility = "hidden";
                    document.getElementById("sp3").style.visibility = "hidden";
                    document.getElementById("sp4").style.visibility = "hidden";
                    document.getElementById("sp5").style.visibility = "hidden";
                    document.getElementById("sp6").style.visibility = "hidden";
                    document.getElementById("sp7").style.visibility = "hidden";
                    document.getElementById("sp8").style.visibility = "hidden";
                    document.getElementById("sumRow").style.backgroundColor = "#ffffff";
                    document.getElementById("status").innerHTML = "";
                    exchange2.amount1 = $scope.amount11;
                    exchange2.amount2 = $scope.amount12;
                };

                $scope.doExchange5 = function () {

                    var dif = $scope.amount11 - $scope.amount22;
                    if (dif > $scope.credit1) {

                        $scope.amount12 = $scope.credit2;
                        $scope.amount22 = $scope.credit1;


                        document.getElementById("sumRow").style.backgroundColor = "#d9534f";
                        document.getElementById("status").innerHTML = "Failed!, It Exceeded the credit limit!";


                    } else {

                        document.getElementById("sumRow").style.backgroundColor = "#5cb85c";
                        document.getElementById("status").innerHTML = "Done successfully!";


                    }

                    document.getElementById("sp3").style.visibility = "visible";
                    document.getElementById("sp6").style.visibility = "visible";
                    document.getElementById("sp1").style.visibility = "visible";
                    document.getElementById("sp2").style.visibility = "visible";
                    document.getElementById("sp4").style.visibility = "visible";
                    document.getElementById("sp5").style.visibility = "visible";
                    document.getElementById("sp7").style.visibility = "visible";
                    document.getElementById("sp8").style.visibility = "visible";

                };
            }

        })

        .state('getstarted12', {
            url: '/getstarted12',
            templateUrl: 'view3/subviews/12.html',


        })

        .state('getstarted13', {
            url: '/getstarted13',
            templateUrl: 'view3/subviews/13.html',
            controller: function ($scope) {


            }

        })

        .state('getstarted14', {
            url: '/getstarted14',
            templateUrl: 'view3/subviews/14.html',
            controller: function ($scope, Currencies1, Channel1) {


                $scope.currencies = [];
                $scope.currencies1 = Currencies1;
                $scope.channel = Channel1;


                $scope.createChannel = function () {

                    $scope.channel.setCurrencies([$scope.currencies[0], $scope.currencies[1]]);

                };
            }

        })
        .state('getstarted15', {
            url: '/getstarted15',
            templateUrl: 'view3/subviews/15.html',
            controller: function ($scope, Channel1) {

                $scope.coordinatorTypes = ['bank', 'trader', 'money changer'];

                //
                //
                var channel = Channel1;

                $scope.currencies = channel.getCurrencies();
                //
                $scope.coordinators1 = [];
                var coordinator1 = {name: " ", type: " ", ownership: " ", currency: $scope.currencies[0]};
                $scope.coordinators1.push(coordinator1);
                $scope.baseNumber1 = 0;
                //
                //

                $scope.count1 = 0;


                $scope.coordinatorNameIds1 = [];
                $scope.coordinatorTypeIds1 = [];
                $scope.coordinatorOwnershipId1s1 = [];
                $scope.coordinatorOwnershipId2s1 = [];
                $scope.coordinatorOwnershipId3s1 = [];

                $scope.coordinatorNameVars1 = [];
                $scope.coordinatorTypeVars1 = [];
                $scope.coordinatorOwnershipNames1 = [];


                var coordinatorNameBaseId1 = "coordinatorName-1";
                var coordinatorTypeBaseId1 = "coordinatorType-1";
                var coordinatorOwnershipBaseId1 = "ownershipType-1";
                var coordinatorOwnershipBaseName1 = "ownershipType1";


                $scope.coordinatorNameIds1[$scope.baseNumber1] = coordinatorNameBaseId1 + $scope.baseNumber1;
                $scope.coordinatorTypeIds1[$scope.baseNumber1] = coordinatorTypeBaseId1 + $scope.baseNumber1;
                $scope.coordinatorOwnershipId1s1[$scope.baseNumber1] = coordinatorOwnershipBaseId1 + $scope.baseNumber1 + "1";
                $scope.coordinatorOwnershipId2s1[$scope.baseNumber1] = coordinatorOwnershipBaseId1 + $scope.baseNumber1 + "2";
                $scope.coordinatorOwnershipId3s1[$scope.baseNumber1] = coordinatorOwnershipBaseId1 + $scope.baseNumber1 + "3";

                $scope.coordinatorOwnershipNames1[$scope.baseNumber1] = coordinatorOwnershipBaseName1 + $scope.baseNumber1;

                $scope.coordinators2 = [];
                var coordinator2 = {name: " ", type: " ", ownership: " ", currency: $scope.currencies[1]};
                $scope.coordinators2.push(coordinator2);
                $scope.baseNumber2 = 0;
                $scope.count2 = 0;

                $scope.coordinatorNameIds2 = [];
                $scope.coordinatorTypeIds2 = [];
                $scope.coordinatorOwnershipId1s2 = [];
                $scope.coordinatorOwnershipId2s2 = [];
                $scope.coordinatorOwnershipId3s2 = [];

                $scope.coordinatorNameVars2 = [];
                $scope.coordinatorTypeVars2 = [];
                $scope.coordinatorOwnershipNames2 = [];

                //
                var coordinatorNameBaseId2 = "coordinatorName-2";
                var coordinatorTypeBaseId2 = "coordinatorType-2";
                var coordinatorOwnershipBaseId2 = "ownershipType-2";

                var coordinatorOwnershipBaseName2 = "ownershipType2";

                $scope.coordinatorNameIds2[$scope.baseNumber2] = coordinatorNameBaseId2 + $scope.baseNumber2;
                $scope.coordinatorTypeIds2[$scope.baseNumber2] = coordinatorTypeBaseId2 + $scope.baseNumber2;
                $scope.coordinatorOwnershipId1s2[$scope.baseNumber2] = coordinatorOwnershipBaseId2 + $scope.baseNumber2 + "1";
                $scope.coordinatorOwnershipId2s2[$scope.baseNumber2] = coordinatorOwnershipBaseId2 + $scope.baseNumber2 + "2";
                $scope.coordinatorOwnershipId3s2[$scope.baseNumber2] = coordinatorOwnershipBaseId2 + $scope.baseNumber2 + "3";

                $scope.coordinatorOwnershipNames2[$scope.baseNumber2] = coordinatorOwnershipBaseName2 + $scope.baseNumber2;


                $scope.addCoordinator1box = function () {
                    //
                    $scope.baseNumber1++;
                    //
                    var coordinator1 = {name: " ", type: " ", ownership: " ", currency: $scope.currencies[0]};
                    $scope.coordinators1.push(coordinator1);
                    //
                    $scope.coordinatorNameIds1[$scope.baseNumber1] = coordinatorNameBaseId1 + $scope.baseNumber1;
                    $scope.coordinatorTypeIds1[$scope.baseNumber1] = coordinatorTypeBaseId1 + $scope.baseNumber1;
                    $scope.coordinatorOwnershipId1s1[$scope.baseNumber1] = coordinatorOwnershipBaseId1 + $scope.baseNumber1 + "1";
                    $scope.coordinatorOwnershipId2s1[$scope.baseNumber1] = coordinatorOwnershipBaseId1 + $scope.baseNumber1 + "2";
                    $scope.coordinatorOwnershipId3s1[$scope.baseNumber1] = coordinatorOwnershipBaseId1 + $scope.baseNumber1 + "3";

                    $scope.coordinatorOwnershipNames1[$scope.baseNumber1] = coordinatorOwnershipBaseName1 + $scope.baseNumber1;

                    //
                    //
                    //
                };
                //
                //

                $scope.addCoordinator2box = function () {

                    $scope.baseNumber2++;

                    var coordinator2 = {name: " ", type: " ", ownership: " ", currency: $scope.currencies[1]};
                    $scope.coordinators2.push(coordinator2);
                    //
                    $scope.coordinatorNameIds2[$scope.baseNumber2] = coordinatorNameBaseId2 + $scope.baseNumber2;
                    $scope.coordinatorTypeIds2[$scope.baseNumber2] = coordinatorTypeBaseId2 + $scope.baseNumber2;
                    $scope.coordinatorOwnershipId1s2[$scope.baseNumber2] = coordinatorOwnershipBaseId2 + $scope.baseNumber2 + "1";
                    $scope.coordinatorOwnershipId2s2[$scope.baseNumber2] = coordinatorOwnershipBaseId2 + $scope.baseNumber2 + "2";
                    $scope.coordinatorOwnershipId3s2[$scope.baseNumber2] = coordinatorOwnershipBaseId2 + $scope.baseNumber2 + "3";

                    $scope.coordinatorOwnershipNames2[$scope.baseNumber2] = coordinatorOwnershipBaseName2 + $scope.baseNumber2;


                };

                $scope.next = function () {

                    var i;
                    for (i = 0; i < $scope.coordinators1.length; i++) {

                        $scope.coordinators1[i].name = $scope.coordinatorNameVars1[i];
                        $scope.coordinators1[i].type = $scope.coordinatorTypeVars1[i];

                        if (document.getElementById($scope.coordinatorOwnershipId1s1[i]).checked) {
                            $scope.coordinators1[i].ownership = document.getElementById($scope.coordinatorOwnershipId1s1[i]).value;
                        } else if (document.getElementById($scope.coordinatorOwnershipId2s1[i]).checked) {
                            $scope.coordinators1[i].ownership = document.getElementById($scope.coordinatorOwnershipId2s1[i]).value;
                        } else if (document.getElementById($scope.coordinatorOwnershipId3s1[i]).checked) {
                            $scope.coordinators1[i].ownership = document.getElementById($scope.coordinatorOwnershipId3s1[i]).value;
                        }

                        $scope.coordinators1[i].currency = $scope.currencies[0];


                        channel.addCoordinator1($scope.coordinators1[i]);
                    }


                    var j;
                    for (j = 0; j < $scope.coordinators2.length; j++) {

                        $scope.coordinators2[j].name = $scope.coordinatorNameVars2[j];
                        $scope.coordinators2[j].type = $scope.coordinatorTypeVars2[j];

                        if (document.getElementById($scope.coordinatorOwnershipId1s2[j]).checked) {
                            $scope.coordinators2[j].ownership = document.getElementById($scope.coordinatorOwnershipId1s2[j]).value;
                        } else if (document.getElementById($scope.coordinatorOwnershipId2s2[j]).checked) {
                            $scope.coordinators2[j].ownership = document.getElementById($scope.coordinatorOwnershipId2s2[j]).value;
                        } else if (document.getElementById($scope.coordinatorOwnershipId3s2[j]).checked) {
                            $scope.coordinators2[j].ownership = document.getElementById($scope.coordinatorOwnershipId3s2[j]).value;
                        }

                        $scope.coordinators2[j].currency = $scope.currencies[1];

                        channel.addCoordinator2($scope.coordinators2[j]);
                    }

                };
            }
        })


        .state('getstarted16', {
            url: '/getstarted16',
            templateUrl: 'view3/subviews/16.html',
            controller: function ($scope, Channel1, Channel2, GetRates1) {


                var channel = Channel1;

                $scope.coordinators = [];
                $scope.coordinators[0] = channel.getCoordinators1();
                $scope.coordinators[1] = channel.getCoordinators2();


                $scope.customersLogs = [];
                $scope.importersLogs = [];
                $scope.exportersLogs = [];

                $scope.baseCurrency = "";
                $scope.requiredCredit = 0;

                $scope.currencies = channel.getCurrencies();

                $scope.agreements = [];
                $scope.customers = [];
                $scope.exchanges = [];

                $scope.availableCredit1 = 0;
                $scope.availableCredit2 = 0;
                $scope.requiredCredit1 = 0;
                $scope.requiredCredit2 = 0;

                $scope.coordinators = channel.getCoordinators1().concat(channel.getCoordinators2());

                $scope.providersCount = 0;
                $scope.customersCount = 0;
                $scope.exchangesCount = 0;

                $scope.scopeProvidersCount = 0;
                $scope.scopeCustomersCount = 0;
                $scope.scopeExchangesCount = 0;

                $scope.customerNameIds = [];
                $scope.customerCoordinatorIds = [];
                $scope.customerAccountBalanceBeforeIds = [];
                $scope.customerAccountBalanceAfterIds = [];
                $scope.customerCurrencyIds = [];

                $scope.customerNameVars = [];
                $scope.customerCoordinatorVars = [];
                $scope.customerAccountBalanceBeforeVars = [];
                $scope.customerAccountBalanceAfterVars = [];
                $scope.customerCurrencyVars = [];


                var customerNameBaseId = "customerName-";
                var customerCoordinatorBaseId = "customerCoordinator-";
                var customerAccountBalanceBeforeBaseId = "customerAccountBalanceBefore-";
                var customerAccountBalanceAfterBaseId = "customerAccountBalanceAfter-";
                var customerCurrencyBaseId = "customerCurrency-";


                var customer = {name: " ", currency: "", coordinator: " ", balanceBefore: " "};
                $scope.customers.push(customer);

                $scope.customerNameIds[$scope.customersCount] = customerNameBaseId + $scope.customersCount;
                $scope.customerCoordinatorIds[$scope.customersCount] = customerCoordinatorBaseId + $scope.customersCount;
                $scope.customerAccountBalanceBeforeIds[$scope.customersCount] = customerAccountBalanceBeforeBaseId + $scope.customersCount;
                $scope.customerAccountBalanceAfterIds[$scope.customersCount] = customerAccountBalanceAfterBaseId + $scope.customersCount;
                $scope.customerCurrencyIds[$scope.customersCount] = customerCurrencyBaseId + $scope.customersCount;

                $scope.addCustomerBox2 = function () {

                    $scope.customersCount++;

                    var customer = {name: " ", currency: "", coordinator: " ", balanceBefore: " "};
                    $scope.customers.push(customer);

                    $scope.customerNameIds[$scope.customersCount] = customerNameBaseId + $scope.customersCount;
                    $scope.customerCoordinatorIds[$scope.customersCount] = customerCoordinatorBaseId + $scope.customersCount;
                    $scope.customerAccountBalanceBeforeIds[$scope.customersCount] = customerAccountBalanceBeforeBaseId + $scope.customersCount;
                    $scope.customerAccountBalanceAfterIds[$scope.customersCount] = customerAccountBalanceAfterBaseId + $scope.customersCount;
                    $scope.customerCurrencyIds[$scope.customersCount] = customerCurrencyBaseId + $scope.customersCount;

                };


                $scope.importerNameIds = [];
                // $scope.importerFieldOfActivityIds = [];
                $scope.importerFeeIds = [];
                $scope.importerCoordinatorIds = [];
                $scope.importerCreditBeforeIds = [];
                $scope.importerCreditAfterIds = [];
                $scope.importerCurrencyIds = [];
                $scope.importerDueToIds = [];


                $scope.exporterNameIds = [];
                // $scope.exporterFieldOfActivityIds = [];
                $scope.exporterFeeIds = [];
                $scope.exporterCoordinatorIds = [];
                $scope.exporterCreditBeforeIds = [];
                $scope.exporterCreditAfterIds = [];
                $scope.exporterCurrencyIds = [];
                $scope.exporterDueToIds = [];

                $scope.importerNameVars = [];
                // $scope.importerFieldOfActivityVars = [];
                $scope.importerCurrencyVars = [];
                $scope.importerCoordinatorVars = [];
                $scope.importerCreditBeforeVars = [];
                $scope.importerCreditAfterVars = [];
                $scope.importerFeeVars = [];
                $scope.importerDueToVars = [];


                $scope.exporterNameVars = [];
                // $scope.exporterFieldOfActivityVars = [];
                $scope.exporterCurrencyVars = [];
                $scope.exporterCoordinatorVars = [];
                $scope.exporterCreditBeforeVars = [];
                $scope.exporterCreditAfterVars = [];
                $scope.exporterFeeVars = [];
                $scope.exporterDueToVars = [];


                var importerNameBaseId = "importerName-";
                // var importerFieldOfActivityBaseId = "importerFieldOfActivity-";
                var importerCoordinatorBaseId = "importerCoordinator-";
                var importerCreditBeforeBaseId = "importerCreditBefore-";
                var importerCreditAfterBaseId = "importerCreditAfter-";
                var importerFeeBaseId = "importerFee-";
                var importerDueToBaseId = "importerDueTo-";


                var exporterNameBaseId = "exporterName-";
                // var exporterFieldOfActivityBaseId = "exporterFieldOfActivity-";
                var exporterCoordinatorBaseId = "exporterCoordinator-";
                var exporterCreditBeforeBaseId = "exporterCreditBefore-";
                var exporterCreditAfterBaseId = "exporterCreditAfter-";
                var exporterFeeBaseId = "exporterFee-";
                var exporterDueToBaseId = "exporterDueTo-";


                var importer = {name: " ", currency: " ", coordinator: " ", credit: "", fee: ""};
                var exporter = {name: " ", currency: " ", coordinator: " ", credit: "", fee: ""};

                var agreement = {importer: importer, exporter: exporter};
                $scope.agreements.push(agreement);

                $scope.importerNameIds[$scope.providersCount] = importerNameBaseId + $scope.providersCount;
                // $scope.importerFieldOfActivityIds[$scope.providersCount] = importerFieldOfActivityBaseId + $scope.providersCount;
                $scope.importerCoordinatorIds[$scope.providersCount] = importerCoordinatorBaseId + $scope.providersCount;
                $scope.importerCreditBeforeIds[$scope.providersCount] = importerCreditBeforeBaseId + $scope.providersCount;
                $scope.importerCreditAfterIds[$scope.providersCount] = importerCreditAfterBaseId + $scope.providersCount;
                $scope.importerFeeIds[$scope.providersCount] = importerFeeBaseId + $scope.providersCount;
                $scope.importerDueToIds[$scope.providersCount] = importerDueToBaseId + $scope.providersCount;

                $scope.exporterNameIds[$scope.providersCount] = exporterNameBaseId + $scope.providersCount;
                // $scope.exporterFieldOfActivityIds[$scope.providersCount] = exporterFieldOfActivityBaseId + $scope.providersCount;
                $scope.exporterCoordinatorIds[$scope.providersCount] = exporterCoordinatorBaseId + $scope.providersCount;
                $scope.exporterCreditBeforeIds[$scope.providersCount] = exporterCreditBeforeBaseId + $scope.providersCount;
                $scope.exporterCreditAfterIds[$scope.providersCount] = exporterCreditAfterBaseId + $scope.providersCount;
                $scope.exporterFeeIds[$scope.providersCount] = exporterFeeBaseId + $scope.providersCount;
                $scope.exporterDueToIds[$scope.providersCount] = exporterDueToBaseId + $scope.providersCount;

                $scope.addProviderBox2 = function () {

                    $scope.providersCount++;

                    var importer = {name: " ", currency: " ", coordinator: " ", credit: "", fee: ""};
                    var exporter = {name: " ", currency: " ", coordinator: " ", credit: "", fee: ""};

                    var agreement = {importer: importer, exporter: exporter};
                    $scope.agreements.push(agreement);

                    $scope.importerNameIds[$scope.providersCount] = importerNameBaseId + $scope.providersCount;
                    // $scope.importerFieldOfActivityIds[$scope.providersCount] = importerFieldOfActivityBaseId + $scope.providersCount;
                    $scope.importerCoordinatorIds[$scope.providersCount] = importerCoordinatorBaseId + $scope.providersCount;
                    $scope.importerCreditBeforeIds[$scope.providersCount] = importerCreditBeforeBaseId + $scope.providersCount;
                    $scope.importerCreditAfterIds[$scope.providersCount] = importerCreditAfterBaseId + $scope.providersCount;
                    $scope.importerFeeIds[$scope.providersCount] = importerFeeBaseId + $scope.providersCount;
                    $scope.importerDueToIds[$scope.providersCount] = importerDueToBaseId + $scope.providersCount;

                    $scope.exporterNameIds[$scope.providersCount] = exporterNameBaseId + $scope.providersCount;
                    // $scope.exporterFieldOfActivityIds[$scope.providersCount] = exporterFieldOfActivityBaseId + $scope.providersCount;
                    $scope.exporterCoordinatorIds[$scope.providersCount] = exporterCoordinatorBaseId + $scope.providersCount;
                    $scope.exporterCreditBeforeIds[$scope.providersCount] = exporterCreditBeforeBaseId + $scope.providersCount;
                    $scope.exporterCreditAfterIds[$scope.providersCount] = exporterCreditAfterBaseId + $scope.providersCount;
                    $scope.exporterFeeIds[$scope.providersCount] = exporterFeeBaseId + $scope.providersCount;
                    $scope.exporterDueToIds[$scope.providersCount] = exporterDueToBaseId + $scope.providersCount;

                };

                $scope.exchangeIdIds = [];
                $scope.exchangeFromIds = [];
                $scope.exchangeToIds = [];
                $scope.exchangeAmount1Ids = [];
                $scope.exchangeAmount2Ids = [];
                $scope.exchangeMaxFeeIds = [];
                $scope.exchangeFeeAmountIds = [];

                $scope.exchangeIdVars = [];
                $scope.exchangeFromVars = [];
                $scope.exchangeToVars = [];
                $scope.exchangeAmount1Vars = [];
                $scope.exchangeAmount2Vars = [];
                $scope.exchangeMaxFeeVars = [];
                $scope.exchangeFeeAmountVars = [];

                var exchangeIdBaseId = "exchangeId-";
                var exchangeFromBaseId = "exchangeFrom-";
                var exchangeToBaseId = "exchangeTo-";
                var exchangeAmount1BaseId = "exchangeAmount1-";
                var exchangeAmount2BaseId = "exchangeAmount2-";
                var exchangeMaxFeeBaseId = "exchangeMaxFee-";
                var exchangeFeeAmountBaseId = "exchangeFeeAmount-";

                var exchange = {ID1: "", from: " ", to1: "", amount1: "", amount2: ""};
                $scope.exchanges.push(exchange);

                $scope.exchangeIdVars[0] = "1";

                $scope.exchangeIdIds[$scope.exchangesCount] = exchangeIdBaseId + $scope.exchangesCount;
                $scope.exchangeFromIds[$scope.exchangesCount] = exchangeFromBaseId + $scope.exchangesCount;
                $scope.exchangeToIds[$scope.exchangesCount] = exchangeToBaseId + $scope.exchangesCount;
                $scope.exchangeAmount1Ids[$scope.exchangesCount] = exchangeAmount1BaseId + $scope.exchangesCount;
                $scope.exchangeAmount2Ids[$scope.exchangesCount] = exchangeAmount2BaseId + $scope.exchangesCount;
                $scope.exchangeMaxFeeIds[$scope.exchangesCount] = exchangeMaxFeeBaseId + $scope.exchangesCount;
                $scope.exchangeFeeAmountIds[$scope.exchangesCount] = exchangeFeeAmountBaseId + $scope.exchangesCount;


                $scope.addExchangeBox2 = function () {

                    $scope.exchangesCount++;
                    var exchange = {ID1: "", from: " ", to1: "", amount1: "", amount2: ""};
                    $scope.exchanges.push(exchange);

                    $scope.exchangeIdIds[$scope.exchangesCount] = exchangeIdBaseId + $scope.exchangesCount;
                    $scope.exchangeFromIds[$scope.exchangesCount] = exchangeFromBaseId + $scope.exchangesCount;
                    $scope.exchangeToIds[$scope.exchangesCount] = exchangeToBaseId + $scope.exchangesCount;
                    $scope.exchangeAmount1Ids[$scope.exchangesCount] = exchangeAmount1BaseId + $scope.exchangesCount;
                    $scope.exchangeAmount2Ids[$scope.exchangesCount] = exchangeAmount2BaseId + $scope.exchangesCount;
                    $scope.exchangeMaxFeeIds[$scope.exchangesCount] = exchangeMaxFeeBaseId + $scope.exchangesCount;
                    $scope.exchangeFeeAmountIds[$scope.exchangesCount] = exchangeFeeAmountBaseId + $scope.exchangesCount;

                    $scope.exchangeIdVars[$scope.exchangesCount] = $scope.exchangesCount + 1;
                };


                $scope.refreshProviders = function () {

                    $scope.availableCredit1 = 0;
                    $scope.availableCredit2 = 0;
                    $scope.requiredCredit1 = 0;
                    $scope.requiredCredit2 = 0;

                    var i;
                    for (i = 0; i < $scope.agreements.length; i++) {

                        $scope.agreements[i].importer.name = $scope.importerNameVars[i];
                        $scope.agreements[i].exporter.name = $scope.exporterNameVars[i];


                        $scope.agreements[i].importer.coordinator = $scope.importerCoordinatorVars[i];
                        $scope.agreements[i].exporter.coordinator = $scope.exporterCoordinatorVars[i];

                        $scope.agreements[i].importer.currency = $scope.importerCurrencyVars[i];
                        $scope.agreements[i].exporter.currency = $scope.exporterCurrencyVars[i];

                        $scope.agreements[i].importer.credit = parseInt($scope.importerCreditBeforeVars[i]);
                        $scope.agreements[i].exporter.credit = parseInt($scope.exporterCreditBeforeVars[i]);

                        $scope.agreements[i].importer.fee = parseInt($scope.importerFeeVars[i]);
                        $scope.agreements[i].exporter.fee = parseInt($scope.exporterFeeVars[i]);

                        if ($scope.agreements[i].importer.currency === $scope.currencies[0]) {
                            $scope.availableCredit1 += parseInt($scope.agreements[i].importer.credit);
                        } else {
                            $scope.availableCredit2 += parseInt($scope.agreements[i].importer.credit);
                        }

                        if ($scope.agreements[i].exporter.currency === $scope.currencies[0]) {
                            $scope.availableCredit1 += parseInt($scope.agreements[i].exporter.credit);
                        } else {
                            $scope.availableCredit2 += parseInt($scope.agreements[i].exporter.credit);
                        }

                        $scope.importersLogs[i] = [];
                        $scope.exportersLogs[i] = [];
                    }


                };

                $scope.refreshCustomers = function () {

                    var i;
                    for (i = 0; i < $scope.customers.length; i++) {

                        // $scope.customers[i].name = $scope.customerNameVars[i];
                        // $scope.customers[i].coordinator = $scope.customerCoordinatorVars[i];
                        // $scope.customers[i].currency = $scope.customerCurrencyVars[i];
                        // $scope.customers[i].balanceBefore = parseInt($scope.customerAccountBalanceBeforeVars[i]);
                        // $scope.customers[i].balanceAfter = parseInt($scope.customerAccountBalanceAfterVars[i]);
                        $scope.customersLogs[i] = [];
                    }
                };


                $scope.f1 = function (counter) {

                    $scope.customerCurrencyVars[counter] = $scope.customerCoordinatorVars[counter].currency;
                };

                $scope.f2 = function (counter) {


                    $scope.importerCurrencyVars[counter] = $scope.importerCoordinatorVars[counter].currency;
                };

                $scope.f3 = function (counter) {
                    $scope.exporterCurrencyVars[counter] = $scope.exporterCoordinatorVars[counter].currency;
                };

                $scope.f4 = function (counter) {

                    var r = GetRates1.getRates($scope.exchangeFromVars[counter].currency, $scope.exchangeToVars[counter].currency);

                    $scope.exchangeAmount2Vars[counter] = ($scope.exchangeAmount1Vars[counter] * (r[0] / r[1])).toFixed(0);


                };

                var ok = true;
                var toBalance = 0;

                var currency1Amounts = 0;
                var currency2Amounts = 0;

                var availableCredit = 0;


                var myRefreshExChanges = function () {
                    currency1Amounts = 0;
                    currency2Amounts = 0;
                    ok = true;

                    var i;
                    for (i = 0; i < $scope.exchanges.length; i++) {

                        $scope.exchanges[i].ID1 = $scope.exchangeIdVars[i];
                        $scope.exchanges[i].from = $scope.exchangeFromVars[i];
                        $scope.exchanges[i].to1 = $scope.exchangeToVars[i];
                        $scope.exchanges[i].amount1 = parseInt($scope.exchangeAmount1Vars[i]);
                        $scope.exchanges[i].amount2 = parseInt($scope.exchangeAmount2Vars[i]);
                        $scope.exchanges[i].maxFee = parseInt($scope.exchangeMaxFeeVars[i]);

                        if ($scope.exchanges[i].from.currency === $scope.currencies[0]) {
                            currency1Amounts -= $scope.exchanges[i].amount1;
                            currency2Amounts += $scope.exchanges[i].amount2;

                        } else {
                            currency2Amounts -= $scope.exchanges[i].amount1;
                            currency1Amounts += $scope.exchanges[i].amount2;

                        }

                    }

                    var r = GetRates1.getRates($scope.currencies[0], $scope.currencies[1]);


                    if (currency1Amounts < 0) {
                        $scope.requiredCredit1 = Math.abs(currency1Amounts);
                        $scope.requiredCredit2 = ($scope.requiredCredit1 * (r[0] / r[1])).toFixed(0);
                        $scope.baseCurrency = $scope.currencies[1];
                        toBalance = (-1) * currency2Amounts;
                        $scope.requiredCredit = $scope.requiredCredit2;
                        availableCredit = $scope.availableCredit2;

                    } else {

                        $scope.requiredCredit2 = Math.abs(currency2Amounts);
                        $scope.requiredCredit1 = ($scope.requiredCredit2 * (r[1] / r[0])).toFixed(0);
                        $scope.baseCurrency = $scope.currencies[0];
                        toBalance = (-1) * currency1Amounts;
                        $scope.requiredCredit = $scope.requiredCredit1;
                        availableCredit = $scope.availableCredit1;
                    }
                };


                // $scope.refreshExchanges = function () {

                // myRefreshExChanges();

                // };


                $scope.exchange = function () {

                    // var totalCredit

                    var i;
                    for (i = 0; i < $scope.exchanges.length; i++) {

                        if ($scope.exchanges[i].amount1 > $scope.exchanges[i].from.balanceBefore) {
                            ok = false;
                            // alert("hello");
                            alert("Exchange failed, not enough account balanceBefore by : " + $scope.exchanges[i].from.name);
                            break;

                        }
                    }

                    if (ok) {

                        if ($scope.requiredCredit > availableCredit) {

                            alert("not enough credit");

                        } else {

                            for (i = 0; i < $scope.exchanges.length; i++) {

                                var j;

                                for (j = 0; j < $scope.customers.length; j++) {
                                    if ($scope.customers[j].name === $scope.exchanges[i].from.name) {

                                        $scope.customerAccountBalanceBeforeVars[j] = parseInt($scope.customerAccountBalanceBeforeVars[j]) - parseInt($scope.exchanges[i].amount1);
                                        $scope.customers[j].balanceBefore = $scope.customerAccountBalanceBeforeVars[j];

                                        var log = {
                                            ID: $scope.exchanges[i].ID1,
                                            to1: $scope.exchanges[i].to1.name,
                                            amount: (-1) * $scope.exchanges[i].amount1
                                        };
                                        $scope.customersLogs[j].push(log);
                                        break;
                                    }

                                }


                                var l;

                                for (l = 0; l < $scope.customers.length; l++) {
                                    if ($scope.customers[l].name === $scope.exchanges[i].to1.name) {

                                        $scope.customerAccountBalanceBeforeVars[l] = parseInt($scope.customerAccountBalanceBeforeVars[l]) + parseInt($scope.exchanges[i].amount2);
                                        $scope.customers[l].balanceBefore = $scope.customerAccountBalanceBeforeVars[l];
                                        var log = {
                                            ID: $scope.exchanges[i].ID1,
                                            from: $scope.exchanges[i].from.name,
                                            amount: $scope.exchanges[i].amount2
                                        };
                                        $scope.customersLogs[l].push(log);

                                        break;
                                    }

                                }

                            }


                            var tempProviders = [];
                            var n;

                            for (n = 0; n < $scope.agreements.length; n++) {
                                if ($scope.agreements[n].importer.currency === $scope.baseCurrency) {
                                    tempProviders.push($scope.agreements[n].importer);

                                } else {
                                    tempProviders.push($scope.agreements[n].exporter);
                                }
                            }

                            tempProviders.sort(function (a, b) {
                                return a.fee - b.fee;
                            });


                            var k;
                            for (k = 0; k < tempProviders.length && toBalance < 0; k++) {

                                var index = 0;
                                var isImporter = false;

                                for (let b = 0; b < $scope.agreements.length; b++) {

                                    if ($scope.agreements[b].importer === tempProviders[k]) {
                                        isImporter = true;
                                        index = b;
                                        break;
                                    } else if ($scope.agreements[b].exporter === tempProviders[k]) {

                                        index = b;
                                        break;
                                    }

                                }

                                if (isImporter) {

                                    var temp = Math.min($scope.importerCreditBeforeVars[index], Math.abs(toBalance));
                                    $scope.importerCreditAfterVars[index] = parseInt($scope.importerCreditBeforeVars[index]) - temp;
                                    toBalance = toBalance + temp;

                                    var temp2;
                                    var r = GetRates1.getRates($scope.agreements[index].importer.currency, $scope.agreements[index].exporter.currency);
                                    temp2 = parseInt((temp * (r[0] / r[1])).toFixed(0));
                                    $scope.exporterCreditAfterVars[index] = parseInt($scope.exporterCreditBeforeVars[index]) + parseInt(temp2);
                                } else {

                                    var temp3 = Math.min($scope.exporterCreditBeforeVars[index], Math.abs(toBalance));
                                    $scope.exporterCreditAfterVars[index] = parseInt($scope.exporterCreditBeforeVars[index]) - temp3;
                                    toBalance = toBalance + temp3;

                                    var temp4;
                                    var r1 = GetRates1.getRates($scope.agreements[index].exporter.currency, $scope.agreements[index].importer.currency);
                                    temp4 = parseInt((temp3 * (r1[0] / r1[1])).toFixed(0));
                                    $scope.importerCreditAfterVars[index] = parseInt($scope.importerCreditBeforeVars[index]) + parseInt(temp4);

                                }

                            }

                        }

                    }

                };

                $scope.next = function () {
                    for (var i = 0; i < $scope.agreements.length; i++) {
                        channel.addAgreement($scope.agreements[i]);
                    }

                    for (var j = 0; j < $scope.customers.length; j++) {
                        channel.addCustomers($scope.customers[j]);
                    }

                };
            }
        })

        .state('getstarted17', {
            url: '/getstarted17',
            templateUrl: 'view3/subviews/17.html',
            controller: function ($scope) {

            }

        })

        .state('getstarted18', {
            url: '/getstarted18',
            templateUrl: 'view3/subviews/18.html',
            controller: function ($scope, Currencies1, Channel2) {

                $scope.currenciesCount = 0;
                $scope.currencies1 = Currencies1;
                $scope.channel = Channel2;
                $scope.currentCurrencies = $scope.channel.getCurrencies();

                // $scope.currentCurrenciesCount = $scope.currencies.

                $scope.currentCurrenciesCount = $scope.currentCurrencies.length;
                $scope.newCurrencies = [];
                $scope.newCurrenciesCount = -1;

                $scope.findCurrencyIndex = function (currency) {
                    for (let i = 0; i < $scope.currentCurrencies.length; i++) {
                        if ($scope.currentCurrencies[i] === currency) {

                            return i;

                        }
                    }
                };


                $scope.addCurrencyBox = function () {

                    $scope.newCurrenciesCount++;
                    var newCurrency = "" + $scope.newCurrenciesCount;
                    $scope.newCurrencies.push(newCurrency);
                };

                $scope.createChannel = function () {
                    var currencies = $scope.currentCurrencies.concat($scope.newCurrencies);
                    $scope.channel.setCurrencies(currencies);

                };
            }

        })

        .state('getstarted19', {
            url: '/getstarted19',
            templateUrl: 'view3/subviews/19.html',
            controller: function ($scope, Channel1, Channel2) {

                $scope.coordinatorTypes = ['bank', 'trader', 'money changer'];

                $scope.channel = Channel2;
                $scope.currencies = $scope.channel.getCurrencies();

                $scope.currencyCount = 0;

                //
                $scope.coordinators = [];
                $scope.coordinatorsCount = [];
                //
                //

                $scope.coordinatorNameIds = [];
                $scope.coordinatorTypeIds = [];
                $scope.coordinatorOwnershipId1s = [];
                $scope.coordinatorOwnershipId2s = [];
                $scope.coordinatorOwnershipId3s = [];
                $scope.coordinatorNameVars = [];
                $scope.coordinatorTypeVars = [];
                $scope.coordinatorOwnershipNames = [];


                for (let i = 0; i < $scope.currencies.length; i++) {

                    $scope.coordinators[i] = [];
                    var coordinator = {name: " ", type: " ", ownership: " ", currency: $scope.currencies[i]};
                    $scope.coordinators[i].push(coordinator);

                    $scope.coordinatorNameIds[i] = [];
                    $scope.coordinatorTypeIds[i] = [];
                    $scope.coordinatorOwnershipId1s[i] = [];
                    $scope.coordinatorOwnershipId2s[i] = [];
                    $scope.coordinatorOwnershipId3s[i] = [];

                    $scope.coordinatorNameVars[i] = [];
                    $scope.coordinatorTypeVars[i] = [];
                    $scope.coordinatorOwnershipNames[i] = [];
                    $scope.coordinatorsCount[i] = 0;

                    $scope.currencyCount++;

                }

                var coordinatorNameBaseIds = [];
                var coordinatorTypeBaseIds = [];
                var coordinatorOwnershipBaseIds = [];
                var coordinatorOwnershipBaseNames = [];

                for (let j = 0; j < $scope.currencies.length; j++) {

                    coordinatorNameBaseIds[j] = "coordinatorName-" + j;
                    coordinatorTypeBaseIds[j] = "coordinatorType-" + j;
                    coordinatorOwnershipBaseIds[j] = "ownershipType-" + j;
                    coordinatorOwnershipBaseNames[j] = "ownershipType" + j;

                }

                $scope.coordinatorNameIds[0][$scope.coordinatorsCount[0]] = coordinatorNameBaseIds[0] + $scope.coordinatorsCount[0];
                $scope.coordinatorTypeIds[0][$scope.coordinatorsCount[0]] = coordinatorTypeBaseIds[0] + $scope.coordinatorsCount[0];
                $scope.coordinatorOwnershipId1s[0][$scope.coordinatorsCount[0]] = coordinatorOwnershipBaseIds[0] + $scope.coordinatorsCount[0] + "1";
                $scope.coordinatorOwnershipId2s[0][$scope.coordinatorsCount[0]] = coordinatorOwnershipBaseIds[0] + $scope.coordinatorsCount[0] + "2";
                $scope.coordinatorOwnershipId3s[0][$scope.coordinatorsCount[0]] = coordinatorOwnershipBaseIds[0] + $scope.coordinatorsCount[0] + "3";

                $scope.coordinatorOwnershipNames[0][$scope.coordinatorsCount[0]] = coordinatorOwnershipBaseNames[0] + $scope.coordinatorsCount[0];


                $scope.addCoordinator1box = function (count) {
                    //
                    $scope.coordinatorsCount[count]++;
                    //
                    var coordinator = {name: " ", type: " ", ownership: " ", currency: $scope.currencies[count]};

                    $scope.coordinators[count].push(coordinator);
                    //
                    $scope.coordinatorNameIds[count][$scope.coordinatorsCount[count]] = coordinatorNameBaseIds[count] + $scope.coordinatorsCount[count];
                    $scope.coordinatorTypeIds[count][$scope.coordinatorsCount[count]] = coordinatorTypeBaseIds[count] + $scope.coordinatorsCount[count];
                    $scope.coordinatorOwnershipId1s[count][$scope.coordinatorsCount[count]] = coordinatorOwnershipBaseIds[count] + $scope.coordinatorsCount[count] + "1";
                    $scope.coordinatorOwnershipId2s[count][$scope.coordinatorsCount[count]] = coordinatorOwnershipBaseIds[count] + $scope.coordinatorsCount[count] + "2";
                    $scope.coordinatorOwnershipId3s[count][$scope.coordinatorsCount[count]] = coordinatorOwnershipBaseIds[count] + $scope.coordinatorsCount[count] + "3";

                    $scope.coordinatorOwnershipNames[count][$scope.coordinatorsCount[count]] = coordinatorOwnershipBaseNames[count] + $scope.coordinatorsCount[count];

                };

                $scope.findCurrencyIndex = function (currency) {
                    for (let i = 0; i < $scope.currencies.length; i++) {
                        if ($scope.currencies[i] === currency) {
                            return i;

                        }
                    }
                };

                $scope.next = function () {

                    $scope.channel.buildCoordinators();

                    for (let j = 0; j < $scope.coordinators.length; j++) {

                        for (let i = 0; i < $scope.coordinators[j].length; i++) {

                            $scope.coordinators[j][i].name = $scope.coordinatorNameVars[j][i];
                            // $scope.coordinators[j][i].type = $scope.coordinatorTypeVars[j][i];


                            //
                            // if (document.getElementById($scope.coordinatorOwnershipId1s[j][i]).checked) {
                            //     $scope.coordinators[j][i].ownership = document.getElementById($scope.coordinatorOwnershipId1s[j][i]).value;
                            // } else if (document.getElementById($scope.coordinatorOwnershipId2s[j][i]).checked) {
                            //     $scope.coordinators[j][i].ownership = document.getElementById($scope.coordinatorOwnershipId2s[j][i]).value;
                            // } else if (document.getElementById($scope.coordinatorOwnershipId3s[j][i]).checked) {
                            //     $scope.coordinators[j][i].ownership = document.getElementById($scope.coordinatorOwnershipId3s[j][i]).value;
                            // }
                            //
                            // $scope.coordinators[j][i].currency = $scope.currencies[0];
                            $scope.channel.addCoordinator($scope.coordinators[j][i], j);

                        }


                    }


                };
            }

        })

        .state('getstarted20', {
            url: '/getstarted20',
            templateUrl: 'view3/subviews/20.html',
            controller: function ($scope, Channel2, Graph, GetRates1, Page20) {


                $scope.channel = Channel2;
                var graph = Graph;
                var page20 = Page20;

                //
                $scope.customersLogs = [];
                $scope.importersLogs = [];
                $scope.exportersLogs = [];

                $scope.baseCurrency = "";
                $scope.requiredCredit = 0;

                $scope.coordinators = $scope.channel.getCoordinators();
                $scope.currencies = $scope.channel.getCurrencies();

                // $scope.customers = $scope.channel.getCustomers();
                // $scope.exchanges = $scope.channel.getExchanges();

                $scope.exchangeRegisterd = false;

                var copyAllCoordinators = [];
                var copyAgreements = [];

                var toBalances = [];
                var currencyAmounts = [];

                for (let j = 0; j < $scope.currencies.length; j++) {
                    toBalances[j] = 0;
                }


                $scope.availableCredits = [];
                for (let i = 0; i < $scope.currencies.length; i++) {
                    $scope.availableCredits[i] = 0;
                }

                $scope.requiredCredits = [];
                for (let i = 0; i < $scope.currencies.length; i++) {
                    $scope.requiredCredits[i] = {currency: $scope.currencies[i], amount: 0};
                }


                $scope.allCoordinators = $scope.coordinators[0];
                for (let i = 1; i < $scope.coordinators.length; i++) {
                    $scope.allCoordinators = $scope.allCoordinators.concat($scope.coordinators[i]);
                }

                if (!page20.isVisited()) {


                    $scope.providersCount = 0;
                    $scope.customersCount = 0;
                    $scope.exchangesCount = 0;

                    $scope.exchangesIndexCount = 0;
                    $scope.exchangesIndex = [];


                    $scope.scopeProvidersCount = 0;
                    $scope.scopeCustomersCount = 0;
                    $scope.scopeExchangesCount = 0;
                }

                $scope.customerNameIds = [];
                $scope.customerCoordinatorIds = [];
                $scope.customerAccountBalanceBeforeIds = [];
                $scope.customerAccountBalanceAfterIds = [];
                $scope.customerCurrencyIds = [];

                $scope.customerNameVars = [];
                $scope.customerCoordinatorVars = [];
                $scope.customerAccountBalanceBeforeVars = [];
                $scope.customerAccountBalanceAfterVars = [];
                $scope.customerCurrencyVars = [];


                var customerNameBaseId = "customerName-";
                var customerCoordinatorBaseId = "customerCoordinator-";
                var customerAccountBalanceBeforeBaseId = "customerAccountBalanceBefore-";
                var customerAccountBalanceAfterBaseId = "customerAccountBalanceAfter-";
                var customerCurrencyBaseId = "customerCurrency-";

                if (!page20.isVisited()) {

                    var customer = {
                        name: " ",
                        currency: "",
                        coordinator: " ",
                        balanceBefore: " ",
                        balanceAfter: "",
                        logs1: []
                    };
                    $scope.channel.addCustomer(customer);
                }


                $scope.customerNameIds[$scope.customersCount] = customerNameBaseId + $scope.customersCount;
                $scope.customerCoordinatorIds[$scope.customersCount] = customerCoordinatorBaseId + $scope.customersCount;
                $scope.customerAccountBalanceBeforeIds[$scope.customersCount] = customerAccountBalanceBeforeBaseId + $scope.customersCount;
                $scope.customerAccountBalanceAfterIds[$scope.customersCount] = customerAccountBalanceAfterBaseId + $scope.customersCount;
                $scope.customerCurrencyIds[$scope.customersCount] = customerCurrencyBaseId + $scope.customersCount;

                $scope.addCustomerBox2 = function () {

                    $scope.customersCount++;

                    var customer = {
                        name: " ",
                        currency: "",
                        coordinator: " ",
                        balanceBefore: " ",
                        balanceAfter: "",
                        logs1: []
                    };
                    $scope.channel.addCustomer(customer);

                    $scope.customerNameIds[$scope.customersCount] = customerNameBaseId + $scope.customersCount;
                    $scope.customerCoordinatorIds[$scope.customersCount] = customerCoordinatorBaseId + $scope.customersCount;
                    $scope.customerAccountBalanceBeforeIds[$scope.customersCount] = customerAccountBalanceBeforeBaseId + $scope.customersCount;
                    $scope.customerAccountBalanceAfterIds[$scope.customersCount] = customerAccountBalanceAfterBaseId + $scope.customersCount;
                    $scope.customerCurrencyIds[$scope.customersCount] = customerCurrencyBaseId + $scope.customersCount;

                };


                $scope.importerNameIds = [];
                // $scope.importerFieldOfActivityIds = [];
                $scope.importerFeeIds = [];
                $scope.importerCoordinatorIds = [];
                $scope.importerCreditBeforeIds = [];
                $scope.importerCreditAfterIds = [];
                $scope.importerCurrencyIds = [];
                $scope.importerDueToIds = [];


                $scope.exporterNameIds = [];
                // $scope.exporterFieldOfActivityIds = [];
                $scope.exporterFeeIds = [];
                $scope.exporterCoordinatorIds = [];
                $scope.exporterCreditBeforeIds = [];
                $scope.exporterCreditAfterIds = [];
                $scope.exporterCurrencyIds = [];
                $scope.exporterDueToIds = [];

                $scope.importerNameVars = [];
                // $scope.importerFieldOfActivityVars = [];
                $scope.importerCurrencyVars = [];
                $scope.importerCoordinatorVars = [];
                $scope.importerCreditBeforeVars = [];
                $scope.importerCreditAfterVars = [];
                $scope.importerFeeVars = [];
                $scope.importerDueToVars = [];


                $scope.exporterNameVars = [];
                // $scope.exporterFieldOfActivityVars = [];
                $scope.exporterCurrencyVars = [];
                $scope.exporterCoordinatorVars = [];
                $scope.exporterCreditBeforeVars = [];
                $scope.exporterCreditAfterVars = [];
                $scope.exporterFeeVars = [];
                $scope.exporterDueToVars = [];


                var importerNameBaseId = "importerName-";
                // var importerFieldOfActivityBaseId = "importerFieldOfActivity-";
                var importerCoordinatorBaseId = "importerCoordinator-";
                var importerCreditBeforeBaseId = "importerCreditBefore-";
                var importerCreditAfterBaseId = "importerCreditAfter-";
                var importerFeeBaseId = "importerFee-";
                var importerDueToBaseId = "importerDueTo-";


                var exporterNameBaseId = "exporterName-";
                // var exporterFieldOfActivityBaseId = "exporterFieldOfActivity-";
                var exporterCoordinatorBaseId = "exporterCoordinator-";
                var exporterCreditBeforeBaseId = "exporterCreditBefore-";
                var exporterCreditAfterBaseId = "exporterCreditAfter-";
                var exporterFeeBaseId = "exporterFee-";
                var exporterDueToBaseId = "exporterDueTo-";


                if (!page20.isVisited()) {

                    var importer = {name: " ", currency: " ", coordinator: " ", dueTo: "", credit: "", fee: ""};
                    var exporter = {name: " ", currency: " ", coordinator: " ", dueTo: "", credit: "", fee: ""};

                    var agreement = {importer: importer, exporter: exporter};
                    $scope.channel.addAgreement(agreement);

                }

                $scope.importerNameIds[$scope.providersCount] = importerNameBaseId + $scope.providersCount;
                // $scope.importerFieldOfActivityIds[$scope.providersCount] = importerFieldOfActivityBaseId + $scope.providersCount;
                $scope.importerCoordinatorIds[$scope.providersCount] = importerCoordinatorBaseId + $scope.providersCount;
                $scope.importerCreditBeforeIds[$scope.providersCount] = importerCreditBeforeBaseId + $scope.providersCount;
                $scope.importerCreditAfterIds[$scope.providersCount] = importerCreditAfterBaseId + $scope.providersCount;
                $scope.importerFeeIds[$scope.providersCount] = importerFeeBaseId + $scope.providersCount;
                $scope.importerDueToIds[$scope.providersCount] = importerDueToBaseId + $scope.providersCount;

                $scope.exporterNameIds[$scope.providersCount] = exporterNameBaseId + $scope.providersCount;
                // $scope.exporterFieldOfActivityIds[$scope.providersCount] = exporterFieldOfActivityBaseId + $scope.providersCount;
                $scope.exporterCoordinatorIds[$scope.providersCount] = exporterCoordinatorBaseId + $scope.providersCount;
                $scope.exporterCreditBeforeIds[$scope.providersCount] = exporterCreditBeforeBaseId + $scope.providersCount;
                $scope.exporterCreditAfterIds[$scope.providersCount] = exporterCreditAfterBaseId + $scope.providersCount;
                $scope.exporterFeeIds[$scope.providersCount] = exporterFeeBaseId + $scope.providersCount;
                $scope.exporterDueToIds[$scope.providersCount] = exporterDueToBaseId + $scope.providersCount;

                $scope.addProviderBox2 = function () {

                    $scope.providersCount++;

                    var importer = {
                        name: " ",
                        currency: " ",
                        coordinator: " ",
                        fee: "",
                        creditBefore: "",
                        dueTo: "",
                        creditAfter: ""
                    };
                    var exporter = {
                        name: " ",
                        currency: " ",
                        coordinator: " ",
                        fee: "",
                        creditBefore: "",
                        dueTo: "",
                        creditAfter: ""
                    };

                    var agreement = {importer: importer, exporter: exporter};
                    $scope.channel.addAgreement(agreement);

                    $scope.importerNameIds[$scope.providersCount] = importerNameBaseId + $scope.providersCount;
                    // $scope.importerFieldOfActivityIds[$scope.providersCount] = importerFieldOfActivityBaseId + $scope.providersCount;
                    $scope.importerCoordinatorIds[$scope.providersCount] = importerCoordinatorBaseId + $scope.providersCount;
                    $scope.importerCreditBeforeIds[$scope.providersCount] = importerCreditBeforeBaseId + $scope.providersCount;
                    $scope.importerCreditAfterIds[$scope.providersCount] = importerCreditAfterBaseId + $scope.providersCount;
                    $scope.importerFeeIds[$scope.providersCount] = importerFeeBaseId + $scope.providersCount;
                    $scope.importerDueToIds[$scope.providersCount] = importerDueToBaseId + $scope.providersCount;

                    $scope.exporterNameIds[$scope.providersCount] = exporterNameBaseId + $scope.providersCount;
                    // $scope.exporterFieldOfActivityIds[$scope.providersCount] = exporterFieldOfActivityBaseId + $scope.providersCount;
                    $scope.exporterCoordinatorIds[$scope.providersCount] = exporterCoordinatorBaseId + $scope.providersCount;
                    $scope.exporterCreditBeforeIds[$scope.providersCount] = exporterCreditBeforeBaseId + $scope.providersCount;
                    $scope.exporterCreditAfterIds[$scope.providersCount] = exporterCreditAfterBaseId + $scope.providersCount;
                    $scope.exporterFeeIds[$scope.providersCount] = exporterFeeBaseId + $scope.providersCount;
                    $scope.exporterDueToIds[$scope.providersCount] = exporterDueToBaseId + $scope.providersCount;

                };

                $scope.exchangeIdIds = [];
                $scope.exchangeFromIds = [];
                $scope.exchangeToIds = [];
                $scope.exchangeAmount1Ids = [];
                $scope.exchangeAmount2Ids = [];
                $scope.exchangeMaxFeeIds = [];
                $scope.exchangeFeeAmountIds = [];
                $scope.exchangePathIds = [];

                $scope.exchangeIdVars = [];
                $scope.exchangeFromVars = [];
                $scope.exchangeToVars = [];
                $scope.exchangeAmount1Vars = [];
                $scope.exchangeAmount2Vars = [];
                $scope.exchangeMaxFeeVars = [];
                $scope.exchangeFeeAmountVars = [];

                var exchangeIdBaseId = "exchangeId-";
                var exchangeFromBaseId = "exchangeFrom-";
                var exchangeToBaseId = "exchangeTo-";
                var exchangeAmount1BaseId = "exchangeAmount1-";
                var exchangeAmount2BaseId = "exchangeAmount2-";
                var exchangeMaxFeeBaseId = "exchangeMaxFee-";
                var exchangeFeeAmountBaseId = "exchangeFeeAmount-";
                var exchangePathBaseId = "exchangePath-";


                if (!page20.isVisited()) {

                    var exchange = {ID1: "", from: " ", to1: "", amount1: "", amount2: "", feeAmount: "", maxFee: ""};
                    $scope.channel.addExchange(exchange);
                    $scope.channel.getExchanges()[0].ID1 = "1";
                    $scope.exchangesIndex.push(0);
                }

                $scope.exchangeIdIds[$scope.exchangesIndexCount] = exchangeIdBaseId + $scope.exchangesIndexCount;
                $scope.exchangeFromIds[$scope.exchangesIndexCount] = exchangeFromBaseId + $scope.exchangesIndexCount;
                $scope.exchangeToIds[$scope.exchangesIndexCount] = exchangeToBaseId + $scope.exchangesIndexCount;
                $scope.exchangeAmount1Ids[$scope.exchangesIndexCount] = exchangeAmount1BaseId + $scope.exchangesIndexCount;
                $scope.exchangeAmount2Ids[$scope.exchangesIndexCount] = exchangeAmount2BaseId + $scope.exchangesIndexCount;
                $scope.exchangeMaxFeeIds[$scope.exchangesIndexCount] = exchangeMaxFeeBaseId + $scope.exchangesIndexCount;
                $scope.exchangeFeeAmountIds[$scope.exchangesIndexCount] = exchangeFeeAmountBaseId + $scope.exchangesIndexCount;
                $scope.exchangePathIds[$scope.exchangesIndexCount] = exchangePathBaseId + $scope.exchangesIndexCount;


                $scope.addExchangeBox2 = function () {

                    $scope.exchangesCount++;
                    $scope.exchangesIndexCount++;
                    $scope.exchangesIndex.push($scope.exchangesIndexCount);

                    var exchange = {ID1: "", from: " ", to1: "", amount1: "", amount2: "", feeAmount: "", maxFee: ""};
                    $scope.channel.addExchange(exchange);

                    $scope.exchangeIdIds[$scope.exchangesIndexCount] = exchangeIdBaseId + $scope.exchangesIndexCount;
                    $scope.exchangeFromIds[$scope.exchangesIndexCount] = exchangeFromBaseId + $scope.exchangesIndexCount;
                    $scope.exchangeToIds[$scope.exchangesIndexCount] = exchangeToBaseId + $scope.exchangesIndexCount;
                    $scope.exchangeAmount1Ids[$scope.exchangesIndexCount] = exchangeAmount1BaseId + $scope.exchangesIndexCount;
                    $scope.exchangeAmount2Ids[$scope.exchangesIndexCount] = exchangeAmount2BaseId + $scope.exchangesIndexCount;
                    $scope.exchangeMaxFeeIds[$scope.exchangesIndexCount] = exchangeMaxFeeBaseId + $scope.exchangesIndexCount;
                    $scope.exchangeFeeAmountIds[$scope.exchangesIndexCount] = exchangeFeeAmountBaseId + $scope.exchangesIndexCount;
                    $scope.exchangePathIds[$scope.exchangesIndexCount] = exchangePathBaseId + $scope.exchangesIndexCount;

                    $scope.channel.getExchanges()[$scope.exchangesIndexCount].ID1 = $scope.exchangesIndexCount + 1;


                };


                $scope.refreshCustomers = function () {

                    var i;
                    for (i = 0; i < $scope.channel.getCustomers().length; i++) {

                        // $scope.customers[i].name = $scope.customerNameVars[i];
                        // $scope.customers[i].coordinator = $scope.customerCoordinatorVars[i];
                        // $scope.customers[i].currency = $scope.customerCurrencyVars[i];
                        // $scope.customers[i].balanceBefore = parseInt($scope.customerAccountBalanceBeforeVars[i]);
                        $scope.channel.getCustomers()[i].balanceBefore = parseInt($scope.channel.getCustomers()[i].balanceBefore);
                        $scope.channel.getCustomers()[i].balanceAfter = parseInt($scope.channel.getCustomers()[i].balanceBefore);

                        // alert("balance before is : " + $scope.channel.getCustomers()[i].balanceBefore);


                        $scope.customersLogs[i] = [];
                    }
                };

                $scope.undo = function () {

                    for (let i = 0; i < $scope.channel.getCustomers().length; i++) {

                        $scope.customerAccountBalanceAfterVars[i] = "";

                        $scope.channel.getCustomers()[i].balanceAfter = $scope.channel.getCustomers()[i].balanceBefore;
                        $scope.channel.getCustomers()[i].logs1 = [];

                        $scope.importerCreditAfterVars[i] = "";
                        $scope.exporterCreditAfterVars[i] = "";

                        $scope.channel.getAgreements()[i].importer.creditAfter = $scope.channel.getAgreements()[i].importer.creditBefore;
                        $scope.channel.getAgreements()[i].exporter.creditAfter = $scope.channel.getAgreements()[i].exporter.creditBefore;

                    }

                    myGetExchangeFee();

                };


                $scope.f1 = function (counter) {

                    $scope.channel.getCustomers()[counter].currency = $scope.channel.getCustomers()[counter].coordinator.currency;
                };

                $scope.f2 = function (counter) {


                    $scope.channel.getAgreements()[counter].importer.currency = $scope.channel.getAgreements()[counter].importer.coordinator.currency;
                };

                $scope.f3 = function (counter) {
                    $scope.channel.getAgreements()[counter].exporter.currency = $scope.channel.getAgreements()[counter].exporter.coordinator.currency;
                };

                $scope.f4 = function (counter) {


                    var r = GetRates1.getRates($scope.channel.getExchanges()[counter].from.currency, $scope.channel.getExchanges()[counter].to1.currency);
                    $scope.channel.getExchanges()[counter].amount2 = ($scope.channel.getExchanges()[counter].amount1 * (r[0] / r[1])).toFixed(0);

                };


                // $scope.f51 = function(counter){

                // $scope.importerCreditAfterVars[counter] = $scope.importerCreditBeforeVars[counter];

                // };

                // $scope.f52 = function(counter){

                // $scope.exporterCreditAfterVars[counter] = $scope.exporterCreditBeforeVars[counter];

                // };

                var getMaxFee = function (exchange) {


                    var maxFee = 0;
                    var sum = 0;


                    var r = GetRates1.getRates(exchange.from.currency, "Dollar");
                    var amount = (exchange.amount1 * r[0] / r[1]);

                    // alert('test for amount: ' + amount);

                    var path = "";

                    while (sum < amount) {

                        // alert(" entering while");
                        var fee = 0;

                        for (var k = 0; k < graph.getNodes().length; k++) {
                            if (exchange.from.coordinator === graph.getNodes()[k].coordinator) {
                                graph.getNodes()[k].distance = 0;

                            } else {
                                graph.getNodes()[k].distance = Number.MAX_SAFE_INTEGER;


                            }
                        }


                        for (var i = 1; i < graph.getNodes().length; i++) {
                            for (var j = 0; j < graph.getEdges().length; j++) {


                                var source = graph.getEdges()[j].source;
                                var destination = graph.getEdges()[j].destination;


                                // alert("source name is :" + source.coordinator.name);
                                // alert("destination name is :" + destination.coordinator.name);
                                // alert("source distance is :" + source.distance);
                                // alert("destination distance is :" + destination.distance);

                                // alert("weight is " + graph.getEdges()[j].weights[graph.getEdges()[j].weights.length - 1].fee);
                                // alert("the destination parent before is : "+ destination.parent.coordinator.name);

                                if (source.distance !== Number.MAX_SAFE_INTEGER && destination.distance > (parseInt(source.distance) +
                                    parseInt(graph.getEdges()[j].weights[graph.getEdges()[j].weights.length - 1].fee))) {
                                    // alert("entered if");

                                    destination.distance = parseInt(source.distance) + parseInt(graph.getEdges()[j].weights[graph.getEdges()[j].weights.length - 1].fee);
                                    destination.parent = source;

                                }
                                if (destination.coordinator !== exchange.from.coordinator) {
                                    // alert("the destination parent after is : " + destination.parent.coordinator.name);

                                } else {

                                    // alert("this is source no parent");
                                }
                            }
                        }


                        var source2 = graph.getNode(exchange.from.coordinator);
                        var tempNode = graph.getNode(exchange.to1.coordinator);
                        var minAmount = Number.MAX_SAFE_INTEGER;


                        while (tempNode !== source2) {

                            // alert("entering while 0");

                            var tempEdge = graph.getEdge(tempNode.parent, tempNode);
                            fee += parseInt(tempEdge.weights[tempEdge.weights.length - 1].fee);
                            // alert("the weights include : ");
                            // for(let i = 0;i < tempEdge.weights.length ; i++)
                            // alert(tempEdge.weights[i].fee);
                            // alert("and i choose " + tempEdge.weights[tempEdge.weights.length - 1].fee);
                            // alert("weights amount here are : " + tempEdge.weights[tempEdge.weights.length - 1].fee);
                            minAmount = Math.min(minAmount, tempEdge.weights[tempEdge.weights.length - 1].amount);
                            tempNode = tempNode.parent;

                        }

                        // alert("test for minAmount:" + minAmount);

                        //alert("min amount : " + minAmount);
                        tempNode = graph.getNode(exchange.to1.coordinator);
                        minAmount = Math.min(minAmount, amount - sum);
                        // alert("minimum amount that can be transferred is : " + minAmount);
                        var subPath = "";


                        var tempNode2 = graph.getNode(exchange.to1.coordinator);
                        // alert("destination : " + tempNode2.coordinator.name);
                        // alert("source : " + source2.coordinator.name);

                        while (tempNode2 !== source2) {

                            // alert("entering while!");

                            var tempEdge2 = graph.getEdge(tempNode2.parent, tempNode2);
                            var minusEdgeFee = -1 * tempEdge2.weights[tempEdge2.weights.length - 1].fee;

                            var index;
                            for (index = 0; index < graph.getEdges().length; index++) {
                                if (graph.getEdges()[index].destination === tempNode2 && graph.getEdges()[index].source === tempNode2.parent) {
                                    break;
                                }
                            }
                            //
                            // if (index < graph.getEdges().length) {
                            //
                            //     var temp = {
                            //         agreementSide1: graph.getEdges()[index].weights[graph.getEdges()[index].weights.length - 1].agreementSide2,
                            //         agreementSide2: graph.getEdges()[index].weights[graph.getEdges()[index].weights.length - 1].agreementSide1,
                            //         amount: minAmount,
                            //         fee: minusEdgeFee
                            //
                            //     };
                            //
                            //
                            //     graph.getEdges()[index].weights.push(temp);
                            //
                            //
                            // }
                            //
                            // else


                            graph.addEdge(tempNode2, tempNode2.parent, graph.getEdges()[index].weights[graph.getEdges()[index].weights.length - 1].agreementSide2, graph.getEdges()[index].weights[graph.getEdges()[index].weights.length - 1].agreementSide1, minAmount, minusEdgeFee);
                            graph.removeEdgeWeight(tempNode2.parent, tempNode2, minAmount);

                            // graph.addEdgeWeight(index, tempNode2, tempNode2.parent, minusEdgeFee, minAmount);


                            subPath = "->" + tempNode2.coordinator.name + subPath + "";
                            // alert(subPath);
                            tempNode2 = tempNode2.parent;


                        }


                        var r2 = GetRates1.getRates("Dollar", exchange.from.currency);

                        var minAmount2 = (minAmount * r2[0] / r2[1]).toFixed(0);
                        // alert("test for minAmount2: " + minAmount2);

                        subPath = tempNode2.coordinator.name + subPath;

                        path += subPath + ", amount: " + minAmount2 + ", fee: " + fee + "%\n";

                        sum += minAmount;
                        maxFee += (minAmount * fee) / amount;

                    }

                    document.getElementById($scope.exchangePathIds[exchange.ID1 - 1]).innerHTML = path;
                    // alert("path for exchange number" + exchange.ID1 + " is : \n" + path);
                    return Math.max(maxFee, 0);

                };


                var myRefreshProviders = function () {


                    for (let h = 0; h < $scope.currencies; h++) {
                        $scope.availableCredits[h] = 0;
                    }


                    var i;
                    for (i = 0; i < $scope.channel.getAgreements().length; i++) {

                        // $scope.channel.getAgreements()[i].importer.name = $scope.importerNameVars[i];
                        // $scope.channel.getAgreements()[i].exporter.name = $scope.exporterNameVars[i];
                        //
                        //
                        // $scope.channel.getAgreements()[i].importer.coordinator = $scope.importerCoordinatorVars[i];
                        // $scope.channel.getAgreements()[i].exporter.coordinator = $scope.exporterCoordinatorVars[i];
                        //
                        // $scope.channel.getAgreements()[i].importer.currency = $scope.importerCurrencyVars[i];
                        // $scope.channel.getAgreements()[i].exporter.currency = $scope.exporterCurrencyVars[i];
                        //
                        // $scope.channel.getAgreements()[i].importer.creditBefore = parseInt($scope.importerCreditBeforeVars[i]);
                        // $scope.channel.getAgreements()[i].exporter.creditBefore = parseInt($scope.exporterCreditBeforeVars[i]);
                        //
                        $scope.channel.getAgreements()[i].importer.creditAfter = parseInt($scope.channel.getAgreements()[i].importer.creditBefore);
                        $scope.channel.getAgreements()[i].exporter.creditAfter = parseInt($scope.channel.getAgreements()[i].exporter.creditBefore);
                        //
                        //
                        // $scope.channel.getAgreements()[i].importer.fee = parseInt($scope.importerFeeVars[i]);
                        // $scope.channel.getAgreements()[i].exporter.fee = parseInt($scope.exporterFeeVars[i]);

                        $scope.findCurrencyIndex = function (currency) {
                            for (let i = 0; i < $scope.currencies.length; i++) {
                                if ($scope.currencies[i] === currency) {
                                    return i;
                                }
                            }
                        };

                        for (let u = 0; u < $scope.currencies.length; u++) {

                            if ($scope.channel.getAgreements()[i].importer.currency === $scope.currencies[u]) {
                                $scope.availableCredits[u] += parseInt($scope.channel.getAgreements()[i].importer.credit);
                            }

                            if ($scope.channel.getAgreements()[i].exporter.currency === $scope.currencies[u]) {
                                $scope.availableCredits[u] += parseInt($scope.channel.getAgreements()[i].exporter.credit);
                            }

                        }

                        $scope.importersLogs[i] = [];
                        $scope.exportersLogs[i] = [];
                    }

                };


                var myGetExchangeFee = function () {

                    // alert("in the function myGetExchangeFee");
                    myRefreshProviders();

                    copyAllCoordinators = $scope.allCoordinators.slice();
                    copyAgreements = $scope.channel.getAgreements().slice();

                    for (let i = 0; i < copyAgreements.length; i++) {
                        // alert("test for agreement number" + i);

                        // alert(copyAgreements[i].importer.name);
                        // alert(copyAgreements[i].importer.currency);
                        // alert(copyAgreements[i].importer.coordinator.name);
                        //
                        // alert(copyAgreements[i].exporter.name);
                        // alert(copyAgreements[i].exporter.currency);
                        // alert(copyAgreements[i].exporter.coordinator.name);

                    }


                    graph.buildGraph(copyAllCoordinators, copyAgreements);


                    // alert("exchange length is : " + $scope.channel.getExchanges().length);

                    var i;
                    for (i = 0; i < $scope.channel.getExchanges().length; i++) {

                        // alert("test exchanges : " + $scope.exchangeFromVars[i].currency);


                        // $scope.channel.getExchanges()[i].ID1 = $scope.exchangeIdVars[i];
                        // $scope.channel.getExchanges()[i].from = $scope.exchangeFromVars[i];
                        // $scope.channel.getExchanges()[i].to1 = $scope.exchangeToVars[i];
                        // $scope.channel.getExchanges()[i].amount1 = parseInt($scope.exchangeAmount1Vars[i]);
                        // $scope.channel.getExchanges()[i].amount2 = parseInt($scope.exchangeAmount2Vars[i]);

                        // alert("exchange number is : " + i);

                        // alert("test for exchange currency: " + $scope.channel.getExchanges()[i].from.currency);

                        $scope.channel.getExchanges()[i].maxFee = getMaxFee($scope.channel.getExchanges()[i]);
                        $scope.channel.getExchanges()[i].feeAmount = (($scope.channel.getExchanges()[i].amount1 * $scope.channel.getExchanges()[i].maxFee) * 0.01);

                        // $scope.exchangeMaxFeeVars[i] = $scope.channel.getExchanges()[i].maxFee;
                        // $scope.exchangeFeeAmountVars[i] = $scope.channel.getExchanges()[i].feeAmount;

                    }

                };

                $scope.getExchangesFee = function () {
                    // alert("in the function getExchangeFee");
                    $scope.exchangeRegisterd = true;
                    myGetExchangeFee();

                };


                $scope.refreshProviders = function () {

                    myRefreshProviders();

                    if ($scope.exchangeRegisterd) {
                        myGetExchangeFee();
                    }


                };

                $scope.resetPage = function () {

                    $scope.channel.resetChannel();

                    $scope.customersCount = 0;
                    var customer = {
                        name: " ",
                        currency: "",
                        coordinator: " ",
                        balanceBefore: " ",
                        balanceAfter: "",
                        logs: []
                    };
                    $scope.channel.addCustomer(customer);


                    $scope.providersCount = 0;
                    var importer = {name: " ", currency: " ", coordinator: " ", dueTo: "", credit: "", fee: ""};
                    var exporter = {name: " ", currency: " ", coordinator: " ", dueTo: "", credit: "", fee: ""};
                    var agreement = {importer: importer, exporter: exporter};
                    $scope.channel.addAgreement(agreement);


                    $scope.exchangesCount = 0;

                    var exchange = {ID1: "", from: " ", to1: "", amount1: "", amount2: ""};
                    $scope.channel.addExchange(exchange);
                    $scope.channel.getExchanges()[0].ID1 = "1";

                };


                $scope.removeExchange = function (counter) {


                    $scope.channel.getExchanges().splice($scope.channel.getExchanges()[$scope.exchangesIndex[counter]], 1);
                    // $scope.exchangeIdVars.splice(counter, 1);

                    for (let i = 0; i < $scope.channel.getExchanges().length; i++) {
                        // alert("id before is " + $scope.channel.getExchanges()[i].ID1);
                        // alert("id vars before is " + $scope.exchangeIdVars[i]);
                        // alert(i+1);
                        //
                        $scope.channel.getExchanges()[i].ID1 = i + 1;
                        // $scope.exchangeIdVars[i] = i + 1;
                        // alert("id after is " + $scope.channel.getExchanges()[i].ID1);
                        // alert("id vars after is " + $scope.exchangeIdVars[i]);


                    }

                    for (let i = counter; i < $scope.exchangesCount; i++) {
                        $scope.exchangesIndex[i]--;

                    }

                    $scope.exchangesIndexCount--;
                    $scope.exchangesIndexCount = Math.max($scope.exchangesIndexCount, -1);

                };


                // var myRefreshExChanges = function () {
                //
                //     for (let i = 0; i < $scope.currencies.length; i++) {
                //
                //         toBalances[i] = 0;
                //     }
                //
                //     for (let i = 0; i < $scope.currencies.length; i++) {
                //         currencyAmounts[i] = 0;
                //     }
                //
                //
                //     // alert("transaction length is : " + $scope.channel.getExchanges().length);
                //     var i;
                //     for (i = 0; i < $scope.channel.getExchanges().length; i++) {


                // $scope.channel.getExchanges()[i].ID1 = $scope.exchangeIdVars[i];
                // $scope.channel.getExchanges()[i].from = $scope.exchangeFromVars[i];
                // $scope.channel.getExchanges()[i].to1 = $scope.exchangeToVars[i];
                // $scope.channel.getExchanges()[i].amount1 = parseInt($scope.exchangeAmount1Vars[i]);
                // $scope.channel.getExchanges()[i].amount2 = parseInt($scope.exchangeAmount2Vars[i]);

                // alert("exchange number is : " + i);

                //         $scope.channel.getExchanges()[i].maxFee = getMaxFee($scope.channel.getExchanges()[i]);
                //         $scope.channel.getExchanges()[i].feeAmount = (($scope.channel.getExchanges()[i].amount1 * $scope.channel.getExchanges()[i].maxFee) * 0.01);
                //
                //         $scope.exchangeMaxFeeVars[i] = $scope.channel.getExchanges()[i].maxFee;
                //         $scope.exchangeFeeAmountVars[i] = $scope.channel.getExchanges()[i].feeAmount;
                //
                //
                //         for (let j = 0; j < $scope.currencies.length; j++) {
                //
                //             if ($scope.channel.getExchanges()[i].from.currency === $scope.currencies[j]) {
                //                 currencyAmounts[j] -= $scope.channel.getExchanges()[i].amount1;
                //             } else if ($scope.channel.getExchanges()[i].to1.currency === $scope.currencies[j]) {
                //
                //                 currencyAmounts[j] += $scope.channel.getExchanges()[i].amount2;
                //             }
                //         }
                //
                //
                //         for (let j = 0; j < $scope.currencies.length; j++) {
                //
                //             if (currencyAmounts[j] < 0) {
                //                 $scope.requiredCredits[j].amount = (-1) * currencyAmounts[j];
                //                 toBalances[j] = currencyAmounts[j];
                //
                //             }
                //         }
                //
                //     }
                //
                // };


                // $scope.refreshExchanges = function () {

                // myRefreshExChanges();

                // };


                $scope.exchange = function () {

                    // var totalCredit
                    var ok = true;

                    var i;
                    for (i = 0; i < $scope.channel.getExchanges().length; i++) {

                        if ($scope.channel.getExchanges()[i].amount1 > $scope.channel.getExchanges()[i].from.balanceBefore) {
                            ok = false;
                            alert("Exchange failed, not enough account balanceBefore by : " + $scope.channel.getExchanges()[i].from.name);
                            break;

                        }
                    }

                    if (ok) {

                        var ok2 = true;

                        var lowCurrency = "";
                        // for (let k = 0; k < $scope.requiredCredits.length; k++) {
                        //     if ($scope.requiredCredits[k].amount > $scope.availableCredits[k]) {
                        //
                        //         ok2 = false;
                        //         lowCurrency = $scope.requiredCredits[k].currency;
                        //         break;
                        //
                        //     }
                        // }

                        if (!ok2) {

                            alert("not enough credit for : " + lowCurrency);

                        } else {

                            for (i = 0; i < $scope.channel.getExchanges().length; i++) {


                                var j;

                                for (j = 0; j < $scope.channel.getCustomers().length; j++) {
                                    if ($scope.channel.getCustomers()[j].name === $scope.channel.getExchanges()[i].from.name) {

                                        $scope.channel.getCustomers()[j].balanceAfter = parseInt($scope.channel.getCustomers()[j].balanceAfter) - parseInt($scope.channel.getExchanges()[i].amount1);
                                        $scope.customerAccountBalanceAfterVars[j] = $scope.channel.getCustomers()[j].balanceAfter;

                                        var log = {
                                            ID1: $scope.channel.getExchanges()[i].ID1,
                                            to1: $scope.channel.getExchanges()[i].to1.name,
                                            amount: (-1) * $scope.channel.getExchanges()[i].amount1
                                        };
                                        $scope.channel.getCustomers()[j].logs1.push(log);
                                        break;
                                    }

                                }


                                var l;

                                for (l = 0; l < $scope.channel.getCustomers().length; l++) {
                                    if ($scope.channel.getCustomers()[l].name === $scope.channel.getExchanges()[i].to1.name) {

                                        $scope.channel.getCustomers()[l].balanceAfter = parseInt($scope.channel.getCustomers()[l].balanceAfter) + parseInt($scope.channel.getExchanges()[i].amount2);
                                        $scope.customerAccountBalanceAfterVars[l] = $scope.channel.getCustomers()[l].balanceAfter;

                                        var log = {
                                            ID1: $scope.channel.getExchanges()[i].ID1,
                                            from: $scope.channel.getExchanges()[i].from.name,
                                            amount: $scope.channel.getExchanges()[i].amount2
                                        };
                                        $scope.channel.getCustomers()[l].logs1.push(log);
                                        break;
                                    }

                                }

                            }

                            var tempProviders = [];
                            for (let n = 0; n < $scope.currencies.length; n++) {
                                tempProviders[n] = [];
                            }

                            var n;

                            // for (n = 0; n < $scope.agreements.length; n++) {
                            //
                            //     for (let m = 0; m < $scope.currencies.length; m++) {
                            //         if ($scope.agreements[n].importer.currency === $scope.currencies[m]) {
                            //
                            //             tempProviders[m].push($scope.agreements[n].importer);
                            //
                            //         } else if ($scope.agreements[n].exporter.currency === $scope.currencies[m]) {
                            //             tempProviders[m].push($scope.agreements[n].exporter);
                            //
                            //
                            //         }
                            //     }
                            // }


                            // for (let n = 0; n < $scope.currencies.length; n++) {
                            //
                            //     tempProviders[n].sort(function (a, b) {
                            //         return a.fee - b.fee;
                            //     });
                            //
                            // }


                            for (let o = 0; o < $scope.channel.getAgreements().length; o++) {


                                $scope.importerCreditAfterVars[o] = $scope.channel.getAgreements()[o].importer.creditAfter;
                                $scope.exporterCreditAfterVars[o] = $scope.channel.getAgreements()[o].exporter.creditAfter;

                            }


                        }

                    }

                };


                $scope.next = function () {
                    for (var i = 0; i < $scope.channel.getAgreements().length; i++) {
                        $scope.channel.addAgreement($scope.channel.getAgreements()[i]);
                    }

                    for (var j = 0; j < $scope.channel.getCustomers().length; j++) {
                        $scope.channel.addCustomers($scope.channel.getCustomers()[j]);
                    }

                };

                // alert("received here");
                page20.visit();

                //.............................................................

                // var channel = Channel1;
                // var graph = Graph;
                //
                // var edges = graph.nodes;
                //
                // $scope.coordinators = [];
                // $scope.customers = [];
                // $scope.agreements = [];
                // $scope.exchanges = [];
                //
                //
                // //generate random coordinators
                // $scope.coordinators.push({name: "a", type: "bank", ownership: "public", currency: "Dollar"});
                // $scope.coordinators.push({name: "b", type: "bank", ownership: "public", currency: "Rial"});
                // $scope.coordinators.push({name: "c", type: "bank", ownership: "public", currency: "Yuan"});
                // $scope.coordinators.push({name: "d", type: "bank", ownership: "public", currency: "Ruble"});
                //
                // //generate random agreements
                //
                //
                // var importers = [];
                // var exporters = [];
                //
                // importers.push({
                //     name: "i1",
                //     currency: "Dollar",
                //     coordinator: $scope.coordinators[0],
                //     credit: 200,
                //     fee: 10
                // });
                // exporters.push({
                //     name: "e1",
                //     currency: "Rial",
                //     coordinator: $scope.coordinators[1],
                //     credit: 150,
                //     fee: 8
                // });
                //
                // importers.push({
                //     name: "i2",
                //     currency: "Dollar",
                //     coordinator: $scope.coordinators[0],
                //     credit: 200,
                //     fee: 7
                // });
                // exporters.push({
                //     name: "e2",
                //     currency: "Rial",
                //     coordinator: $scope.coordinators[1],
                //     credit: 150,
                //     fee: 5
                // });
                //
                //
                // importers.push({
                //     name: "i3",
                //     currency: "Dollar",
                //     coordinator: $scope.coordinators[0],
                //     credit: 300,
                //     fee: 10
                // });
                // exporters.push({
                //     name: "e3",
                //     currency: "Yuan",
                //     coordinator: $scope.coordinators[2],
                //     credit: 125,
                //     fee: 8
                // });
                //
                // importers.push({
                //     name: "i4",
                //     currency: "Dollar",
                //     coordinator: $scope.coordinators[0],
                //     credit: 320,
                //     fee: 9
                // });
                // exporters.push({
                //     name: "e4",
                //     currency: "Yuan",
                //     coordinator: $scope.coordinators[2],
                //     credit: 250,
                //     fee: 11
                // });
                //
                //
                // importers.push({
                //     name: "i5",
                //     currency: "Dollar",
                //     coordinator: $scope.coordinators[0],
                //     credit: 170,
                //     fee: 12
                // });
                // exporters.push({
                //     name: "e5",
                //     currency: "Ruble",
                //     coordinator: $scope.coordinators[3],
                //     credit: 180,
                //     fee: 5
                // });
                //
                // importers.push({
                //     name: "i6",
                //     currency: "Dollar",
                //     coordinator: $scope.coordinators[0],
                //     credit: 160,
                //     fee: 12
                // });
                // exporters.push({
                //     name: "e6",
                //     currency: "Ruble",
                //     coordinator: $scope.coordinators[3],
                //     credit: 140,
                //     fee: 3
                // });
                //
                //
                // importers.push({
                //     name: "i7",
                //     currency: "Rial",
                //     coordinator: $scope.coordinators[1],
                //     credit: 90,
                //     fee: 10
                // });
                // exporters.push({name: "e7", currency: "Yuan", coordinator: $scope.coordinators[2], credit: 80, fee: 8});
                //
                // importers.push({
                //     name: "i8",
                //     currency: "Rial",
                //     coordinator: $scope.coordinators[1],
                //     credit: 110,
                //     fee: 4
                // });
                // exporters.push({
                //     name: "e8",
                //     currency: "Yuan",
                //     coordinator: $scope.coordinators[2],
                //     credit: 130,
                //     fee: 8
                // });
                //
                //
                // importers.push({
                //     name: "i9",
                //     currency: "Rial",
                //     coordinator: $scope.coordinators[1],
                //     credit: 190,
                //     fee: 7
                // });
                // exporters.push({
                //     name: "e9",
                //     currency: "Ruble",
                //     coordinator: $scope.coordinators[3],
                //     credit: 280,
                //     fee: 2
                // });
                //
                // importers.push({
                //     name: "i10",
                //     currency: "Rial",
                //     coordinator: $scope.coordinators[1],
                //     credit: 210,
                //     fee: 8
                // });
                // exporters.push({
                //     name: "e10",
                //     currency: "Ruble",
                //     coordinator: $scope.coordinators[3],
                //     credit: 230,
                //     fee: 3
                // });
                //
                //
                // importers.push({
                //     name: "i9",
                //     currency: "Yuan",
                //     coordinator: $scope.coordinators[2],
                //     credit: 190,
                //     fee: 7
                // });
                // exporters.push({
                //     name: "e9",
                //     currency: "Ruble",
                //     coordinator: $scope.coordinators[3],
                //     credit: 280,
                //     fee: 2
                // });
                //
                // importers.push({
                //     name: "i10",
                //     currency: "Yuan",
                //     coordinator: $scope.coordinators[2],
                //     credit: 300,
                //     fee: 8
                // });
                // exporters.push({
                //     name: "e10",
                //     currency: "Ruble",
                //     coordinator: $scope.coordinators[3],
                //     credit: 310,
                //     fee: 3
                // });
                //
                //
                // for (let i = 0; i < importers.length; i++) {
                //
                //     $scope.agreements.push({importer: importers[i], exporter: exporters[i]});
                // }
                //
                // var customer = {name: " ", currency: "", coordinator: " ", balanceBefore: " ", balanceAfter: ""};
                //
                // $scope.customers.push({
                //     name: "c1",
                //     currency: "Rial",
                //     coordinator: $scope.coordinators[1],
                //     balanceBefore: 100,
                //     balanceAfter: 100
                // });
                // $scope.customers.push({
                //     name: "c2",
                //     currency: "Dollar",
                //     coordinator: $scope.coordinators[0],
                //     balanceBefore: 50,
                //     balanceAfter: 50
                // });
                // $scope.customers.push({
                //     name: "c3",
                //     currency: "Yuan",
                //     coordinator: $scope.coordinators[2],
                //     balanceBefore: 70,
                //     balanceAfter: 70
                //
                // });
                // $scope.customers.push({
                //     name: "c4",
                //     currency: "Ruble",
                //     coordinator: $scope.coordinators[3],
                //     balanceBefore: 200,
                //     balanceAfter: 200
                // });
                //
                //
                // $scope.exchanges.push({
                //     ID1: "1",
                //     from: $scope.customers[0],
                //     to1: $scope.customers[1],
                //     amount1: 50,
                //     amount2: 70,
                //     maxFee: ""
                // });
                // $scope.exchanges.push({
                //     ID1: "2",
                //     from: $scope.customers[0],
                //     to1: $scope.customers[2],
                //     amount1: 60,
                //     amount2: 80,
                //     maxFee: ""
                // });
                // $scope.exchanges.push({
                //     ID1: "3",
                //     from: $scope.customers[2],
                //     to1: $scope.customers[3],
                //     amount1: 40,
                //     amount2: 50,
                //     maxFee: ""
                //
                // });
                // $scope.exchanges.push({
                //     ID1: "4",
                //     from: $scope.customers[3],
                //     to1: $scope.customers[1],
                //     amount1: 65,
                //     amount2: 75,
                //     maxFee: ""
                //
                // });
                // $scope.exchanges.push({
                //     ID1: "5",
                //     from: $scope.customers[1],
                //     to1: $scope.customers[2],
                //     amount1: 90,
                //     amount2: 85,
                //     maxFee: ""
                //
                // });
                //
                //
                // //generate random exchanges
                //
                //
                // getMaxFee($scope.exchanges[0]);
            }

            //
        });

});

myApp

    .controller('column1Controller', function ($scope) {

        $scope.message = 'column1';

        $scope.galaxies = [
            {
                name: 'Milkyway Galaxy',
                distance: '27,000'
            },
            {
                name: 'Andromeda Galaxy',
                distance: '2,560,000'
            },
            {
                name: 'Sagittarius Dwarf',
                distance: '3.400,000'
            }
        ];
    })

    // let's define the column1 controller that we call up in the about state
    .controller('bottom-rowController', function ($scope) {

        $scope.message = 'bottom row';
        $scope.variables = [];
    });


myApp
    .factory('Exchange1', function () {
        return {currency1: '', currency2: '', amount1: '', amount2: ''};
    })

    .factory('Exchange2', function () {
        return {currency1: '', currency2: '', amount1: '', amount2: ''};
    })

    .factory('Exchange3', function () {
        return {currency1: '', currency2: '', amount1: '', amount2: ''};
    })

    .factory('Currencies1', function () {
        return {'Russia': 'Ruble', 'Iran': 'Rial', 'America': 'Dollar', 'China': 'Yuan'};
    })
    .factory('Channel1', function () {

        var currencies = [];
        var agreements = [];
        var coordinators1 = [];
        var coordinators2 = [];
        var customers = [];

        return {
            getCurrencies: function () {
                return currencies;
            },
            getRelations: function () {
                return agreements;
            },

            getCoordinators1: function () {
                return coordinators1;
            },

            getCoordinators2: function () {
                return coordinators2;
            },

            getCustomers: function () {
                return customers;
            },

            addRelation: function (p) {
                agreements.push(p);
            },


            addCoordinator1: function (c) {
                coordinators1.push(c);
            },


            addCoordinator2: function (c) {
                coordinators2.push(c);
            },

            setCurrencies: function (cs) {
                currencies = cs;

            },

            addCurrency: function (c) {
                currencies.push(c);
            },

            addCustomers: function (c) {
                customers.push(c);
            },

        };
    })
    .factory('Channel2', function () {

        var currencies = [];
        var agreements = [];
        var coordinators = [];
        var customers = [];
        var exchanges = [];

        return {

            resetChannel: function () {

                exchanges = [];
                agreements = [];
                customers = [];

            },

            buildCoordinators: function () {
                var i = 0;
                for (i = 0; i < currencies.length; i++) {
                    coordinators[i] = [];
                }
            },

            getCurrencies: function () {
                return currencies;
            },

            getAgreements: function () {
                return agreements;
            },

            getCustomers: function () {
                return customers;
            },

            getCoordinators: function () {
                return coordinators;
            },

            getExchanges: function () {
                return exchanges;
            },

            addAgreement: function (p) {
                agreements.push(p);
            },

            addExchange: function (e) {
                exchanges.push(e);
            },

            addCoordinator: function (c, index) {
                coordinators[index].push(c);
            },

            addCustomer: function (c) {
                customers.push(c);

            },

            setCurrencies: function (cs) {
                currencies = cs;
            },

            addCustomers: function (c) {
                customers.push(c);
            },


        };

    })

    .factory('Graph', function () {

        var nodes = [];
        var edges = [];

        return {

            resetGraph: function () {
                nodes = [];
                edges = [];
            },

            buildGraph: function (allCoordinators, agreements) {

                this.resetGraph();

                for (let i = 0; i < allCoordinators.length; i++) {
                    this.addNode(allCoordinators[i], null, Number.MAX_SAFE_INTEGER);
                }


                for (let i = 0; i < agreements.length; i++) {


                    var temp = agreements[i].importer.creditAfter;
                    var temp2 = agreements[i].exporter.creditAfter;

                    var r = this.getRates(agreements[i].importer.currency, "Dollar");
                    var r2 = this.getRates(agreements[i].exporter.currency, "Dollar");

                    var temp3 = (temp * (r[0] / r[1]));
                    var temp4 = (temp2 * (r2[0] / r2[1]));

                    this.addEdge(this.getNode(agreements[i].importer.coordinator), this.getNode(agreements[i].exporter.coordinator), agreements[i].importer, agreements[i].exporter, temp3, agreements[i].importer.fee);
                    this.addEdge(this.getNode(agreements[i].exporter.coordinator), this.getNode(agreements[i].importer.coordinator), agreements[i].exporter, agreements[i].importer, temp4, agreements[i].exporter.fee);
                }

            },

            getNodes: function () {
                return nodes;
            },

            getEdges: function () {
                return edges;

            },

            addNode: function (coordinator, parent, distance) {

                nodes.push({coordinator: coordinator, parent: parent, distance: distance});

            },

            getNode: function (coordinator) {

                var i;
                for (i = 0; i < nodes.length; i++) {

                    if (nodes[i].coordinator === coordinator) {
                        return nodes[i];
                    }
                }
            },

            addEdge: function (source, destination, agreementSide1, agreementSide2, amount, fee) {

                for (let i = 0; i < edges.length; i++) {
                    if (edges[i].source === source && edges[i].destination === destination) {


                        this.addEdgeWeight(i, agreementSide1, agreementSide2, amount, fee);


                        return;
                    }
                }
                var edge = {
                    source: source,
                    destination: destination,
                    weights: [{
                        agreementSide1: agreementSide1,
                        agreementSide2: agreementSide2,
                        amount: amount,
                        fee: fee
                    }]
                };

                // alert("add edge : " + "source: " + edge.source.coordinator.name + " destination : " + edge.destination.coordinator.name + "amount is :" + amount + "fee is : "  + fee);
                edges.push(edge);
            },


            addEdgeWeight: function (index, agreementSide1, agreementSide2, amount, fee) {

                // const insertionSort = function (nums) {
                //     for (let i = 1; i < nums.length; i++) {
                //         let j = i;
                //         let temp0 = nums[i];
                //         let tmp = temp0.fee;
                //         while (j > 0 && nums[j - 1].fee < tmp) {
                //             nums[j] = nums[j - 1];
                //             j--;
                //         }
                //         nums[j] = temp0;
                //     }
                //     return nums;
                // };

                edges[index].weights.push({
                    agreementSide1: agreementSide1,
                    agreementSide2: agreementSide2,
                    amount: amount,
                    fee: fee
                });

                // alert("add edge weight : " + "agreementside1: " + edges[index].weights[edges[index].weights.length - 1].agreementSide1.name + "agreementside2: " + edges[index].weights[edges[index].weights.length - 1].agreementSide2.name + "amount is : " + amount+ "fee is : " + fee);


                var length = edges[index].weights.length - 1;
                var min = Number.MAX_SAFE_INTEGER;
                var minIndex = 0;
                for (let i = 0; i < edges[index].weights.length; i++) {
                    if (min > edges[index].weights[i].fee) {
                        min = edges[index].weights[i].fee;
                        minIndex = i;
                    }
                }
                var temp = edges[index].weights[minIndex];
                edges[index].weights[minIndex] = edges[index].weights[length];
                edges[index].weights[length] = temp;
                //edges[index].weights = insertionSort(edges[index].weights);

                // for (let i = 0; i < edges[index].weights.length; i++) {
                //
                //     alert("weights are : " + edges[index].weights[i].fee);
                //
                // }

            },

            getRates: function (c1, c2) {


                var r1 = 0;
                var r2 = 0;

                switch (c1) {
                    case "Rial":
                        r1 = 1;
                        break;

                    case "Ruble":
                        r1 = 667;
                        break;

                    case "Dollar":
                        r1 = 42000;
                        break;

                    case "Yuan":
                        r1 = 6122;
                        break;
                }

                switch (c2) {
                    case "Rial":
                        r2 = 1;
                        break;
                    case "Ruble":
                        r2 = 667;
                        break;

                    case "Dollar":
                        r2 = 42000;
                        break;

                    case "Yuan":
                        r2 = 6122;
                        break;

                }


                return [r1, r2];
            },

            removeEdgeWeight: function (source, destination, amount) {


                // alert("min amount is : " + amount);
                for (let i = 0; i < edges.length; i++) {

                    if (edges[i].source === source && edges[i].destination === destination) {
                        edges[i].weights[edges[i].weights.length - 1].amount -= amount;


                        var r = this.getRates("Dollar", edges[i].weights[edges[i].weights.length - 1].agreementSide1.currency);
                        var r2 = this.getRates("Dollar", edges[i].weights[edges[i].weights.length - 1].agreementSide2.currency);


                        var temp = (amount * (r[0] / r[1])).toFixed(0);
                        var temp2 = (amount * (r2[0] / r2[1])).toFixed(0);

                        // alert("agreementside " + edges[i].weights[edges[i].weights.length - 1].agreementSide1.name + "received money: " + temp);
                        // alert("agreementside " + edges[i].weights[edges[i].weights.length - 1].agreementSide2.name + "payed money: " + temp2);

                        // alert("test for temp2 " + temp2);

                        edges[i].weights[edges[i].weights.length - 1].agreementSide1.creditAfter += parseInt(temp);
                        edges[i].weights[edges[i].weights.length - 1].agreementSide2.creditAfter -= parseInt(temp2);

                        if (edges[i].weights[edges[i].weights.length - 1].amount === 0) {


                            edges[i].weights.pop();
                            if (edges[i].weights.length === 0) {

                                edges.splice(i, 1);

                            }


                            // alert("poped with value " + edges[i].weights[edges[i].weights.length - 1].fee);
                            var length = edges[i].weights.length - 1;
                            var min = Number.MAX_SAFE_INTEGER;
                            var minIndex = 0;
                            for (let j = 0; j < edges[i].weights.length; j++) {
                                if (edges[i].weights[j].fee < min) {
                                    min = edges[i].weights[j].fee;
                                    minIndex = j;
                                }

                            }
                            var temp4 = edges[i].weights[minIndex];
                            edges[i].weights[minIndex] = edges[i].weights[length];
                            edges[i].weights[length] = temp4;

                        }
                        break;
                    }
                }
            },

            getEdge: function (source, destination) {
                for (let i = 0; i < edges.length; i++) {
                    if (edges[i].source === source && edges[i].destination === destination) {

                        return edges[i];
                    }
                }
            }

        };
    })

    .factory('Edge', function () {

        return {};
    })

    .factory('Importers1', function () {
        return {
            'Russia': ['RuI1', 'RuI2', 'RuI3'],
            'Iran': ['IrI1', 'IrI2', 'IrI3'],
            'America': ['UsI1', 'UsI2', 'UsI3'],
            'China': ['CnI1', 'CnI2', 'CnI3']
        };
    })

    .factory('Exporters1', function () {
        return {
            'Russia': ['RuE1', 'RuE2', 'RuE3'],
            'Iran': ['IrE1', 'IrE2', 'IrE3'],
            'America': ['UsE1', 'UsE2', 'UsE3'],
            'China': ['CnE1', 'CnE2', 'CnE3']
        };
    })
    .factory('Rates1', function () {
        return {
            'Rial': 1,
            'Dollar': 42000,
            'Yuan': 6122,
            'Ruble': 667
        };
    })

    .factory('GetRates1', function () {
        return {
            getRates: function (c1, c2) {


                var r1 = 0;
                var r2 = 0;

                switch (c1) {
                    case "Rial":
                        r1 = 1;
                        break;

                    case "Ruble":
                        r1 = 667;
                        break;

                    case "Dollar":
                        r1 = 42000;
                        break;

                    case "Yuan":
                        r1 = 6122;
                        break;
                }

                switch (c2) {
                    case "Rial":
                        r2 = 1;
                        break;
                    case "Ruble":
                        r2 = 667;
                        break;

                    case "Dollar":
                        r2 = 42000;
                        break;

                    case "Yuan":
                        r2 = 6122;
                        break;

                }


                return [r1, r2];
            }
        };
    })

    .factory('counter', function () {

        var customerCounter = 0;

        return {
            getCustomerCounter: function () {
                return customerCounter;
            },

            increamentCounter: function () {
                customerCounter++;
            }
        };

    })

    .factory('Page20', function () {
        var isVisited = false;

        return {

            visit: function () {
                isVisited = false;
            },

            isVisited: function () {
                return isVisited;
            }
        }

    })


;


